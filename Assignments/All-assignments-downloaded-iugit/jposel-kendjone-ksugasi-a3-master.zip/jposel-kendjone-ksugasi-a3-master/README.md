# jposel-kendjone-ksugasi-a3
a3 created for jposel-kendjone-ksugasi

# Part 1

## Training

During training, we use the training set to calculate the probabilities of the label to word emissions, label to label transition, label to word pair emissions, and three label transitions. To make the emission probability more resilient, we are also considering label to word suffix - which is the last three letters on a word.

## Simple

The simple algorithm only uses the emission probabilities to determine the part of speech of each word. It does not consider transitions or any other features. This algorithm is extremely fast and surprisingly accurate, considering. The simple algorithm correctly identifies the part of speech of 97.14% of the words in the tiny test data and 94.14% of the words in the larger test data.

## Hidden Markov Model - viterbi

The Viterbi algorithm is a bit more sophisticated algorithm that uses the emission probabilities and the transition probabilities to determine the part of speech of each word. It is a more accurate algorithm than the simple algorithm, and it is still fairly fast. This algorithm maintains the previous set of possible states with accumulated probabilities for each state's highest probable state at that step to that point.

The Viterbi algorithm correctly identifies the part of speech of 100% of the words in the tiny test data and 95.58% of the words in the larger test data.

## Markov Chain Monte Carlo

The third algorithm is the Markov Chain Monte Carlo algorithm. This algorithm uses a much more complex model to determine the part of speech of each word. It considers the emission probabilities, transition probabilities, transition probabilities of the previous part of speech, and emission probabilities of the next word given the current state. To do this, we first create a random initial state set. Then we generate a set of possible state sets weighting by viability and add the first one that meets a random threshold. Each iteration updates the current sample state with a random label for one of the words. Once we have enough samples, we select the state set that has the highest instances. 

This approach is very slow and only slightly more accurate than the simple algorithm. This implementation correctly identifies the part of speech of only 100% of the words in the tiny test data and 94.44% of the words in the larger test data.

To accommodate the poor performance of this approach, we are caching the results of emission probabilities and the more complex probability calculations. There is still an initial slowness, but performance improves as the cache size increases.

## Output

`python3 label.py bc.train bc.test.tiny`

```cmd
==> So far scored 3 sentences with 42 words.
                   Words correct:     Sentences correct: 
   0. Ground truth:      100.00%              100.00%
         1. Simple:       97.62%               66.67%
            2. HMM:      100.00%              100.00%
        3. Complex:      100.00%              100.00%
```

`python3 label.py bc.train bc.test.tiny`

```cmd
==> So far scored 2000 sentences with 29442 words.
                   Words correct:     Sentences correct: 
   0. Ground truth:      100.00%              100.00%
         1. Simple:       94.14%               48.50%
            2. HMM:       95.58%               57.50%
        3. Complex:       94.44%               50.35%
```

# Part 2

## i) 
For this part, using the simple Bayes Net, we only had to focus on the emission probabilities. For emission probabilities I simply chose the two largest 'edge' values for each column, with the higher one corresponding to the airice boundary, and lower corresponding to the icerock boundary. I made this a probability by scaling values between 0 and 1. I experimented with both maximum edge values, and minimum pixel values, but found maximum edge values to be superior in finding boundaries and more consistent across images. 

## ii)
For this part, using the more complex Bayes Net, we had to focus on both emission and transition probabilities. I used the same emission probabilities as above, and calculated transition probabilities as the inverse absolute distance between two rows, in order to encourage smoothness. I then implemented the viterbi algorithm in order to obtain the boundary, by using the cost minimization function of adding -log(probability)

## iii)
For this part, I used basically an identical algorithm as part ii, except altering the probability distribution. I chose to do this in two ways:
a) I simply increased the probability of the corresponding pixel value significantly above any other emission probability. THIS is the algorithm I submitted

b) I forced the algorithm to choose the corresponding pixel value in all possible paths. However, I believed this was a slightly poorer design as the path prior to the pixel was not influenced by this. 

By using option a) you will notice in images that despite substantially increasing the probability of that pixel value, the overall path did not change much compared to part ii). Visually, this i represented by the tiny spot of blue when the red path has moved to the asterisk. The reason why I believe this is happening, is that one single column value will not significantly alter the overall path. I believe if more values had been given, or perhaps a range of values, then there would have been more of an impact. 

Please see sample outputs below:

Here you will see that all algorithms performing quite well to find the boundaries, especially the first which is generally smoother. If the boundaries are not smooth at all, as is the case with the 3rd image, the algorithms will not perform as well. 

![Image1](part2/outputfiles/Screen%20Shot%202021-12-01%20at%204.40.17%20pm.png)
![Image2](part2/outputfiles/Screen%20Shot%202021-12-01%20at%204.40.48%20pm.png)
![Image3](part2/outputfiles/Screen%20Shot%202021-12-01%20at%204.41.20%20pm.png)
![Image4](part2/outputfiles/Screen%20Shot%202021-12-01%20at%204.41.50%20pm.png)
![Image5](part2/outputfiles/Screen%20Shot%202021-12-01%20at%204.42.20%20pm.png)

## Problems/Assumptions
1. For Part iii, the input of column and row value was switched when drawing the asterisk. Please see my question in the Q&A community for more detail. To deal with this I manually switched the inputs when choosing the column and row variables
2. The skeleton code for drawing the output lines drew both lines for the ice_rock_output image. As the assignment sheet implied that the two images should only contain their respective boundaries. So I manually altered this.
3. When running the code on silo, the module imageio was not already installed. However, this was given in the skeleton code. Please keep this in mind if any issues arise. 

# Part 3 - Reading text [By Keerthana Sugasi]

## Problem Statement
The aim is to read the text from a noisy image. This is similar to Optical Character Recognition (OCR). Here we recognize the text character by character.

## Approach

The overall approach is to calculate the probability of the 
black dots(*) and white space in the image pixel by pixel which is defined to be 14 * 25 dimensions.
We can read the text using two approaches:
1. Simple Naive Bayes
2. Hidden Markov models using MAP.

### Naive Bayes:

In this approach we calculate the emission probabilities of the characters in an emission probability dictionary for all the characters possible 
i.e. Uppercase alphabets, lowercase alphabets,digits, special characters or punctuations.
We return the output of the characters with the maximum probability.
~~~
 result += "".join(max(self.emission_probabilities[char], key=lambda x: self.emission_probabilities[char][x]))
~~~
### HMM using MAP:
HMM is a special case of Bayes net. In HMM the probability of transitioning 
to next state depends on the current state.It has 3 parts:
* Initial Probability
* Transition Probability
* Emission Probability

We use MAP (Maximum A Posteriori) to find the text present in the image. MAP uses Viterbi decoding / Algorithm to 
determine the posterior probability of an event occurring.
To achieve the above goal we try to maximize the probability of current state character given an observed character.
We find the probability of each character and pick the char with the highest Probability.
HMM calculates that the probability of a character being the next character based on the probability of its previous set of characters observed.

#### *hmm_image_to_text_v2()*:
In the *hmm_image_to_text_v2()* we use bc.train from part1 as the training text.We calculate the initial, transition and emission probabilities 
if not calculated. We initialise 2 lists of 128 characters to index characters using their ASCII value.
For every test letter in the test letter list we iterate through the train letter list and calculate the probability of each character. If the test character is 
has indexed 0 ie first character, then the probability is calculated using the emission and initial probability and store it in current state list. If not index 0,
then we calculate the result using transition probability as follows.
* For every training letter we calculate the transition probability from the previous selected letter.
* Once the transition probability for every training letter is calculated, the training letter with the highest transition probability is chosen. 

This is realised using **Max heaps**. We take the negative log of the probability to avoid underflow, and it also helps us realise max heap
as general implementation of heaps in python is done through min heap. Because of the taking the negative log of the probabilities it would be easier to get the desired highest probability value.
We pop the result from the heap and to form the string of recognised text from the image.

### Other Utility functions

#### 1. *calculate_matching_pixels(train_letters, test_letters)*
This function is used to calculate the number of matching and non-matching letters (*) and matching and non-matching pixels 
of white spaces for both the training and the testing set. It returns a dictionary of count of matching_asterisk,matching_white_pixel,
nonmatching_asterisk, nonmatching_white_pixel and total_pixels.

#### 2. *calculate_initial_probabilities()*
We calculate the initial probability on the training set from the training text file. Count of characters that appear as the first character of 
a sentence is calculated. Then for each character initial probability is calculated as 
frequency of the character divided by number of lines.
~~~
 self.initial_probabilities[char] = count_map[char] / float(sum(count_map.values()))
~~~

#### 3. *calculate_transition_probabilities()*
We calculate the transition probability from the training text file. We iterate through the training set and remove the characters that are not part of our training alphabet.
We store the previous and current test letter and calculate the probability from transitioning from one character to all other characters from training alphabet. Finally, transition probability is 
calculated as the highest probability among all. 

#### 4. *calculate_emission_probabilities()*
In this function we calculate average number of white pixels and asterisk that are populated in test letters and train letters.
For each test letter, we calculate number of matching asterisk and white pixels between each training letter.
We observe some values fixed which are the priors for match and non-matching characters. These values are decided after experimenting with different values.
Its idea is to use different probability weights for different pixel values  and the that density of the image will be a factor in deciding
the weights we assign to matching & non-matching pixels and black & white space pixels.
Finally, emission probability is calculated as follows:
~~~
self.emission_probabilities[test_letter_index][train_letter] = math.pow(ob1, match_result['matching_asterisk']) * math.pow(ob2, match_result['matching_white_pixel']) 
* math.pow(ob3, match_result['nonmatching_asterisk']) * math.pow(ob4, match_result['nonmatching_white_pixel'])
~~~
where ob1-ob4 are observed values that were decided after experimenting.
### Observations
We can observe that HMM model reads the text more accurately than Naive Bayes especially when there is noise in the image or when the image is unclear.
The main reasons are as follows:
* Naive Bayes only considers the emission probability which is purely dependent on pixel comparison. Hence,
if the image quality is poor it will reflect in the emission probability calculation, therefore in the prediction.
* HMM using initial and transition probabilities in addition to emission probabilities while predicting.
These provide prior knowledge about the details like possible words and sentence formations.
With this prior knowledge HMM can avoid common mis-predictions (Example: i,l predicted as 1) as done by Naive Bayes. 


## References:
1. https://medium.com/@phylypo/nlp-text-segmentation-using-hidden-markov-model-f238743d87eb
2. https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-047-computational-biology-fall-2015/lectures_slides/MIT6_047F15_Lecture05.pdf
3. https://courses.cs.washington.edu/courses/cse546/12wi/assignments/classification/classification.html