###################################
# CS B551 Spring 2021, Assignment #3
#
# Your names and user ids: 
#  - Jacob Posel (jposel)
#  - Kenneth Jones (kendjone)
#  - Keerthana Sugasi (ksugasi)
#
# (Based on skeleton code by D. Crandall)
#


import random
import math


# We've set up a suggested code structure, but feel free to change it. Just
# make sure your code still works with the label.py and pos_scorer.py code
# that we've supplied.
#
class Solver:
    # Calculate the log of the posterior probability of a given sentence
    #  with a given part-of-speech labeling. Right now just returns -999 -- fix this!
    def posterior(self, model, sentence, label):
        prob = 0
        if model == "Simple":
            for word, state in zip(sentence, label):
                prob += math.log(self.get_emission_prob(state,word))
        elif model == "HMM":
            prev = None
            for word, state in zip(sentence, label):
                if prev:
                    prob += math.log(self.get_emission_prob(state,word) * self.get_label_prob(state) * self.get_transition_prob(prev, state))
                else:
                    prob += math.log(self.get_emission_prob(state,word) * self.get_label_prob(state) * self.initial_probabilities[state])
                prev = state
        elif model == "Complex":
            for i, word, state in zip(range(len(sentence)), sentence, label):
                next_word = sentence[i+1] if i < len(sentence) - 1 else None
                prev_state = label[i-1] if i > 0 else -i
                prev_state2 = label[i-2] if i > 1 else -i
                prob += math.log(self.get_complex_probs((prev_state2, prev_state), (word, next_word))[state])
        else:
            print("Unknown algo!")
        
        return prob
        
    labels = []
    # Do the training!
    #
    def train(self, data):
        self.labels = list(set([x for _, l in data for x in l ]))
        self.train_init_counts()
        for sentence, labels in data:
            # self.train_complex(sentence, labels)
            self.train_initial(labels[0])
            self.train_transitions(labels)
            for i, word, label in zip(range(len(sentence)), sentence, labels):
                next_word = sentence[i+1] if i < len(sentence) - 1 else None
                self.train_emission(word, next_word, label)
        self.calculate_probabilities()

    initial_counts = {}
    label_counts = {}
    word_counts = {}
    emission_counts = {}
    coupled_emission_counts = {}
    suffix_emission_counts = {}
    transition_counts = {}
    transition_chain_counts = {}
    o_count = 0

    def train_init_counts(self):
        self.initial_counts = {label: 0 for label in self.labels}
        self.emission_counts = {label: {} for label in self.labels}
        self.label_counts = {label: 0 for label in self.labels}
        self.transition_counts = {prev_label: {label: 0 for label in self.labels+[None]} for prev_label in self.labels+[0]}
        
    def train_initial(self, label):
        self.initial_counts[label] += 1

    def train_emission(self, word, next_word, label):
        self.o_count += 1
        if word not in self.emission_counts[label]:
            self.emission_counts[label][word] = 0
        if word not in self.word_counts:
            self.word_counts[word] = 0
        self.word_counts[word] += 1
        self.label_counts[label] += 1
        self.emission_counts[label][word] += 1
        self.suffix_emission_counts[(label, word[-3:])] = self.suffix_emission_counts.get((label, word[-3:]),0) + 1
        self.coupled_emission_counts[(label, word, next_word)] = self.coupled_emission_counts.get((label, word, next_word),0) + 1
    
    def train_transitions(self, labels):
        for i, label in enumerate(labels):
            prev_label = labels[i-1] if i > 0 else -i
            t_chain = (labels[i-2] if i > 1 else -i, prev_label, label,)
            self.transition_counts[prev_label][label] += 1
            if t_chain not in self.transition_chain_counts:
                self.transition_chain_counts[t_chain] = 0
            self.transition_chain_counts[t_chain] += 1
            if i == len(labels) - 1:
                self.transition_counts[label][None] += 1
            
    initial_probabilities = {}
    label_probs = {}
    word_probs = {}
    label_given_word_pair_probs = {}
    label_given_word_probs = {}
    word_given_label_probs = {}
    suffix_given_label_probs = {}
    transition_probabilities = {}
    transition_chain_probabilities = {}
    word_alpha = 1
    observation_alpha = 1

    
    def calculate_probabilities(self):
        self.observation_alpha = 1/self.o_count
        for label in self.initial_counts:
            self.initial_probabilities[label] = self.initial_counts[label] / sum(self.initial_counts.values())
        
        for label in self.label_counts:
            self.label_probs[label] = self.label_counts[label] / sum(self.label_counts.values())
            self.labels.append(label)
        
        for word in self.word_counts:
            self.word_probs[word] = self.word_counts[word] / sum(self.word_counts.values())
            self.label_given_word_probs[word] = {}
            for label in self.emission_counts:
                self.label_given_word_probs[word][label] = self.emission_counts.get(label,{}).get(word, 0.001) / self.word_counts[word]
        
        for label in self.emission_counts:
            if label not in self.word_given_label_probs:
                self.word_given_label_probs[label] = {}
            for word in self.emission_counts[label]:
                self.word_given_label_probs[label][word] = self.emission_counts[label][word] / self.label_counts[label]
        
        suffix_label_counts = {
            label:  sum( [c for k,c in self.suffix_emission_counts.items() if k[0] == label] )
            for label in self.labels
        }
        for label, suffix in self.suffix_emission_counts:
            self.suffix_given_label_probs[(label, suffix)] = self.suffix_emission_counts[(label, suffix)] / suffix_label_counts[label]

        coupled_label_counts = {
            label: sum([c for k,c in self.coupled_emission_counts.items() if k[0] == label])
            for label in self.labels
        }
        for label, word, next_word in self.coupled_emission_counts:
            self.label_given_word_pair_probs[(label, word, next_word)] = self.coupled_emission_counts[(label, word, next_word)] / coupled_label_counts[label]

        for prev_label in self.labels+[0]:
            count = sum(self.transition_counts[prev_label].values())
            if prev_label not in self.transition_probabilities:
                self.transition_probabilities[prev_label] = {}
            for label in self.labels+[None]:
                self.transition_probabilities[prev_label][label] = (self.transition_counts[prev_label][label] or 0.001) / count

        count = sum(self.transition_chain_counts.values())
        self.transition_chain_probabilities = {
            (l2,l1,l): self.transition_chain_counts.get((l2,l1,l), 0.1) / count 
            for l2 in self.labels+[-1,0] for l1 in self.labels+[0] for l in self.labels
        }
        self.word_alpha = 1/len(self.word_probs)

    def get_label_prob(self, label):
        return self.label_probs.get(label, 0.0001)
    
    emission_prob_cache = {}
    def get_emission_prob(self, label, word):
        if (label,word) in self.emission_prob_cache:
            return self.emission_prob_cache[(label,word)]
        prob = self.emission_prob_cache[(label,word)] = self.word_given_label_probs[label].get(word, self.observation_alpha) \
                * self.label_given_word_probs.get(word,{}).get(label, self.word_probs.get(word, self.observation_alpha)) \
                * self.suffix_given_label_probs.get((label, word[-3:]), self.observation_alpha) #\
        return prob
    
    def get_complex_emission_prob(self, label, word, next_word):
        return self.label_given_word_pair_probs.get((label, word, next_word), self.word_alpha) \
            * self.get_emission_prob(label, word)

    def get_likely_word_label(self, word):
        probs = {
            label: self.get_emission_prob(label, word) * self.get_label_prob(label)
            for label in self.labels
        }
        return max(probs, key=probs.get)
    
    def get_transition_prob(self, prev_label, label):
        return self.transition_probabilities.get(prev_label,{}).get(label,self.observation_alpha)
    
    def get_complex_transition_prob(self, chain:tuple):
        return self.transition_chain_probabilities[chain]

    def simplified(self, sentence):
        return [self.get_likely_word_label(word) for word in sentence]

    def hmm_viterbi(self, sentence):
        labels = list(self.labels)
        prev_step = None # {(...labels): probability, ...}
        for i, word in enumerate(sentence):
            step = {}
            if i == 0:
                for label in labels:
                    step[(label,)] =  math.log(self.get_emission_prob(label, word) * self.initial_probabilities[label] * self.get_label_prob(label))
            else: 
                for label in labels:
                    transitions = {}
                    for key, prev_prob in prev_step.items():
                        prev_label = key[-1]
                        prob = prev_prob + math.log(self.get_transition_prob(prev_label,label))
                        transitions[key + (label,)] = prob
                    key, prob = max(transitions.items(), key=lambda item: item[1])
                    step[key] = prob + math.log(self.get_emission_prob(label,word)) + math.log(self.get_label_prob(label))
            prev_step = step
        
        labels, prob = max(prev_step.items(), key=lambda item: item[1])
        return labels    

    def complex_mcmc(self, sentence):
        word_count=len(sentence)
        samples = []
        iterations = 200
        # burn_in = 100
        labels = list(self.labels)
        sample = random.choices(labels, k=word_count)

        for step in range(iterations):
            # Choose a random label for one word 
            sample[step % word_count] = random.choice(labels)

            for i, word in enumerate(sentence):
                prev_label = sample[i-1] if i > 0 else 0
                prev_label2 = sample[i-2] if i > 1 else -i
                next_word = sentence[i-1] if i > 0 else None
                label_probs = self.get_complex_probs((prev_label2, prev_label),(word, next_word)) 
                prob_sum = sum(label_probs.values())
                label_probs = {label: prob / prob_sum for label, prob in label_probs.items()}

                threshold = random.uniform(0.05, 1.00)
    
                for label,prob in label_probs.items():
                    if threshold < prob:
                        sample[i] = label
                        break

            # if step >= burn_in:
            samples.append(tuple(sample))

        prediction_counts = {}
        for s in samples:
            prediction_counts[s] = prediction_counts.get(s, 0) + 1
        
        predicted_labels = max(prediction_counts.items(), key=lambda item: item[1])[0]

        return predicted_labels
    
    complex_prob_cache = {}
    def get_complex_probs(self, labels:tuple, words:tuple):
        if (labels,words) in self.complex_prob_cache:
            return self.complex_prob_cache[(labels,words)]
        prev_label2, prev_label = labels
        word, next_word = words
        self.complex_prob_cache[(labels,words)] = {
            label: 
                self.get_complex_emission_prob(label, word, next_word)
                # self.get_emission_prob(label, word)
                * self.get_label_prob(label)
                * self.get_transition_prob(prev_label, label)
                * self.get_complex_transition_prob((prev_label2, prev_label, label))
            for label in self.labels
        }
        return self.complex_prob_cache[(labels,words)]

    # This solve() method is called by label.py, so you should keep the interface the
    #  same, but you can change the code itself. 
    # It should return a list of part-of-speech labelings of the sentence, one
    #  part of speech per word.
    #
    def solve(self, model, sentence):
        if model == "Simple":
            return self.simplified(sentence)
        elif model == "HMM":
            return self.hmm_viterbi(sentence)
        elif model == "Complex":
            return self.complex_mcmc(sentence)
        else:
            print("Unknown algo!")