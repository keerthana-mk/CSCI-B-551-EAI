# Part 1

## Training

During training, we use the training set to calculate the probabilities of the label to word emissions, label to label transition, label to word pair emissions, and three label transitions. To make the emission probability more resilient, we are also considering label to word suffix - which is the last three letters on a word.

## Simple

The simple algorithm only uses the emission probabilities to determine the part of speech of each word. It does not consider transitions or any other features. This algorithm is extremely fast and surprisingly accurate, considering. The simple algorithm correctly identifies the part of speech of 97.14% of the words in the tiny test data and 94.14% of the words in the larger test data.

## Hidden Markov Model - viterbi

The Viterbi algorithm is a bit more sophisticated algorithm that uses the emission probabilities and the transition probabilities to determine the part of speech of each word. It is a more accurate algorithm than the simple algorithm, and it is still fairly fast. This algorithm maintains the previous set of possible states with accumulated probabilities for each state's highest probable state at that step to that point.

The Viterbi algorithm correctly identifies the part of speech of 100% of the words in the tiny test data and 95.58% of the words in the larger test data.

## Markov Chain Monte Carlo

The third algorithm is the Markov Chain Monte Carlo algorithm. This algorithm uses a much more complex model to determine the part of speech of each word. It considers the emission probabilities, transition probabilities, transition probabilities of the previous part of speech, and emission probabilities of the next word given the current state. To do this, we first create a random initial state set. Then we generate a set of possible state sets weighting by viability and add the first one that meets a random threshold. Each iteration updates the current sample state with a random label for one of the words. Once we have enough samples, we select the state set that has the highest instances. 

This approach is very slow and only slightly more accurate than the simple algorithm. This implementation correctly identifies the part of speech of only 100% of the words in the tiny test data and 94.44% of the words in the larger test data.

To accommodate the poor performance of this approach, we are caching the results of emission probabilities and the more complex probability calculations. There is still an initial slowness, but performance improves as the cache size increases.

## Output

`python3 label.py bc.train bc.test.tiny`

```cmd
==> So far scored 3 sentences with 42 words.
                   Words correct:     Sentences correct: 
   0. Ground truth:      100.00%              100.00%
         1. Simple:       97.62%               66.67%
            2. HMM:      100.00%              100.00%
        3. Complex:      100.00%              100.00%
```

`python3 label.py bc.train bc.test.tiny`

```cmd
==> So far scored 2000 sentences with 29442 words.
                   Words correct:     Sentences correct: 
   0. Ground truth:      100.00%              100.00%
         1. Simple:       94.14%               48.50%
            2. HMM:       95.58%               57.50%
        3. Complex:       94.44%               50.35%
```