#!/usr/local/bin/python3
#
# Authors: jposel, ksugasi, kendjone
#
# Ice layer finder
# Based on skeleton code by D. Crandall, November 2021
#

from PIL import Image
from numpy import *
from scipy.ndimage import filters
import sys
import imageio

# calculate "Edge strength map" of an image                                                                                                                                      
def edge_strength(input_image):
    grayscale = array(input_image.convert('L'))
    filtered_y = zeros(grayscale.shape)
    filters.sobel(grayscale,0,filtered_y)
    return sqrt(filtered_y**2)

# draw a "line" on an image (actually just plot the given y-coordinates
#  for each x-coordinate)
# - image is the image to draw on
# - y_coordinates is a list, containing the y-coordinates and length equal to the x dimension size
#   of the image
# - color is a (red, green, blue) color triple (e.g. (255, 0, 0) would be pure red
# - thickness is thickness of line in pixels
#
def draw_boundary(image, y_coordinates, color, thickness):
    for (x, y) in enumerate(y_coordinates):
        for t in range( int(max(y-int(thickness/2), 0)), int(min(y+int(thickness/2), image.size[1]-1 )) ):
            image.putpixel((x, t), color)
    return image

def draw_asterisk(image, pt, color, thickness):
    for (x, y) in [ (pt[0]+dx, pt[1]+dy) for dx in range(-3, 4) for dy in range(-2, 3) if dx == 0 or dy == 0 or abs(dx) == abs(dy) ]:
        if 0 <= x < image.size[0] and 0 <= y < image.size[1]:
            image.putpixel((x, y), color)
    return image


# Save an image that superimposes three lines (simple, hmm, feedback) in three different colors 
# (yellow, blue, red) to the filename
def write_output_image(filename, image, simple, hmm, feedback, feedback_pt):
    new_image = draw_boundary(image, simple, (255, 255, 0), 2)
    new_image = draw_boundary(new_image, hmm, (0, 0, 255), 2)
    new_image = draw_boundary(new_image, feedback, (255, 0, 0), 2)
    new_image = draw_asterisk(new_image, feedback_pt, (255, 0, 0), 2)
    imageio.imwrite(filename, new_image)



# main program
#
if __name__ == "__main__":

    if len(sys.argv) != 6:
        raise Exception("Program needs 5 parameters: input_file airice_row_coord airice_col_coord icerock_row_coord icerock_col_coord")

    input_filename = sys.argv[1]
    gt_airice = [ int(i) for i in sys.argv[2:4] ]
    gt_icerock = [ int(i) for i in sys.argv[4:6] ]

    # load in image 
    input_image = Image.open(input_filename).convert('RGB')
    image_array = array(input_image.convert('L'))
    airice_col_coord = gt_airice[0]
    airice_row_coord = gt_airice[1]
    icerock_col_coord = gt_icerock[0]
    icerock_row_coord = gt_icerock[1]

    # load in image 
    input_image = Image.open(input_filename).convert('RGB')
    image_array = array(input_image.convert('L'))

    # compute edge strength mask -- in case it's helpful. Feel free to use this.
    edge_strength2 = edge_strength(input_image)
    airice_simple = []
    icerock_simple = []
    fringe = []
    
    
    #compute simple model by finding two largest edges
    for i in range(edge_strength2.shape[1]):
        indexs = []
        indexs2 = []
        x = image_array[:,i].copy()
        y = edge_strength2[:,i].copy()
        y.sort()
        y = flip(y)
        x.sort()
    
        for j in x:
            indexs.append(where(image_array[:, i] == j)[0][0])
            
        for f in y:
            indexs2.append(where(edge_strength2[:,i] == f)[0][0])
        first_edge = indexs2[0]
        
        for z in indexs2:
            if abs(first_edge-z) >= 10:
                second_edge = z
                break
        air = min(first_edge, second_edge)
        rock = max(first_edge,second_edge)
        
            
            
            
        airice_simple.append(air)
        icerock_simple.append(rock)
        
        
        
        first = indexs[0]
        for k in indexs:
            if abs(first-k) >= 10:
                second = k
                break
        air = min(first, second)
        rock = max(first,second)

        
            
            
            
    
#limit range to only look where we already know top boundary to be 
    first_image_array = image_array[:max(airice_simple) + 10, :]
    edge_strength3 =  edge_strength2[:max(airice_simple) + 10, :]
    fringe_fb = []
    
     

#FIRST LAYER HMM + FEEDBACK
    
    #create the 'fringe'
    for j in range(len(first_image_array[:,0])):
        try:
            fringe.append(([j], -math.log(1/first_image_array[j,0])))
            fringe_fb.append(([j], -math.log(1/first_image_array[j,0])))

        except:
            fringe.append(([j], -math.log(1)))
            fringe_fb.append(([j], -math.log(1)))


    
    curr_row = []
    curr_row_fb = []


    new_fringe = []
    new_fringe_fb = []
    #implemen the viterbi algorithm for the first boundary 
    for z in range(first_image_array.shape[1]):
        column = (edge_strength2[:,z] - min(edge_strength2[:,z]))/(max(edge_strength2[:,z]) - min(edge_strength2[:,z]))

        new_fringe = []
        new_fringe_fb = []        
        for i in range(len(first_image_array[:,0])):
            for x in range(len(fringe)):
                path = fringe[x][0] + [i]
                path_fb = fringe_fb[x][0] + [i]

                #transition probabilities
                try:
                     probability = fringe[x][1] + -math.log(1/abs(x-i))
                     probability_fb = fringe_fb[x][1] + -math.log(1/abs(x-i))
                except:
                     probability = fringe[x][1] + -math.log(1)
                     probability_fb = fringe_fb[x][1] + -math.log(1)
                #emission probabilities
                try:
                    edges = -math.log(column[i])

                    if z == airice_col_coord and i == airice_row_coord:
                        edges_fb = -100
                    else:
                        edges_fb = -math.log(column[i] )
                except:
                    edges = 1000
                    edges_fb = 1000

                curr_row.append((probability + edges, path))
                curr_row_fb.append((probability_fb + edges_fb, path_fb))
                
            best_path_to_row = min(curr_row)
            new_fringe.append([best_path_to_row[1], best_path_to_row[0]])
            curr_row = []                   
            best_path_to_row_fb = min(curr_row_fb)
            new_fringe_fb.append([best_path_to_row_fb[1], best_path_to_row_fb[0]])
            curr_row_fb = []
        fringe_fb = new_fringe_fb
        fringe = new_fringe

 #creating the arrays for the boundaries
    airice_hmm = fringe[0][0][:-1]

    minimum = max(fringe[0][0])+10
    
    airice_feedback = fringe_fb[0][0][:-1]
    minimum_fb = max(fringe_fb[0][0])+10




        
    #SECOND LAYER HMM + FEEDBACK
    
    fringe = []
    fringe_fb = []
    
    #Once again, limit matrix size to only look past where the first boundary was 
    new_image_array = image_array[minimum:, :]
    edges3 = edge_strength2[minimum:,:]
    
    #create 'fringe'
    for j in range(len(edges3[:,0])):
        try:
            fringe.append(([j],  -math.log(1/len(edges3[:,0]))))
            fringe_fb.append(([j],  -math.log(1/len(edges3[:,0]))))

        except:
            fringe.append(([j], -math.log(1)))
            fringe_fb.append(([j], -math.log(1)))


    
    curr_row = []
    curr_row_fb = []


    new_fringe = []
    new_fringe_fb = []
    
    #implement viterbi 
    for z in range(edges3.shape[1]):
        column = (edges3[:,z] - min(edges3[:,z]))/(max(edges3[:,z]) - min(edges3[:,z]))

        new_fringe = []
        new_fringe_fb = []        
        for i in range(len(edges3[:,0])):
            for x in range(len(fringe)):
                path = fringe[x][0] + [i]
                path_fb = fringe_fb[x][0] + [i]

                
                try:
                     probability = fringe[x][1] + -math.log(1/abs(x-i))
                     probability_fb = fringe_fb[x][1] + -math.log(1/abs(x-i))
                except:
                     probability = fringe[x][1] + -math.log(1)
                     probability_fb = fringe_fb[x][1] + -math.log(1)

                try:
                    edges = -math.log(column[i] )

                    if z == icerock_col_coord and i+minimum == icerock_row_coord:
                        edges_fb = -100
                        
                    else:
                        edges_fb = -math.log(column[i] )
                except:
                    edges = 1000
                    edges_fb = 1000

                curr_row.append((probability + edges, path))
                curr_row_fb.append((probability_fb + edges_fb, path_fb))

            best_path_to_row = min(curr_row)
            new_fringe.append([best_path_to_row[1], best_path_to_row[0]])
            curr_row = []                   
            best_path_to_row_fb = min(curr_row_fb)
            new_fringe_fb.append([best_path_to_row_fb[1], best_path_to_row_fb[0]])
            curr_row_fb = []
        fringe_fb = new_fringe_fb
        fringe = new_fringe
        
        
    #create arrays for boundaries    
    icerock_hmm = fringe[0][0][:-1]
    icerock_hmm = array(icerock_hmm)
    icerock_hmm += minimum
    icerock_hmm = list(icerock_hmm)
        
        
    icerock_feedback = fringe_fb[0][0][:-1]
    icerock_feedback = array(icerock_feedback)
    icerock_feedback += minimum_fb
    icerock_feedback = list(icerock_feedback)


    imageio.imwrite('edges.png', uint8(255 * edge_strength2 / (amax(edge_strength2))))

    




        
            
        
        
    


    # Now write out the results as images and a text file
    write_output_image("air_ice_output.png", input_image.copy(), airice_simple, airice_hmm, airice_feedback, gt_airice)
    write_output_image("ice_rock_output.png", input_image, icerock_simple, icerock_hmm, icerock_feedback, gt_icerock)
    with open("layers_output.txt", "w") as fp:
        for i in (airice_simple, airice_hmm, airice_feedback, icerock_simple, icerock_hmm, icerock_feedback):
            fp.write(str(i) + "\n")
