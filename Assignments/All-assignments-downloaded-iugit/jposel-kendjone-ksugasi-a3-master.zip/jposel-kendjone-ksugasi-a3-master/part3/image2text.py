#!/usr/bin/python
#
# Perform optical character recognition, usage:
#     python3 ./image2text.py train-image-file.png train-text.txt test-image-file.png
# 
# Authors: (Keerthana Sugasi; userid: ksugasi)
# (based on skeleton code by D. Crandall, Oct 2020)
#
import math
import copy
import heapq
import re

from PIL import Image, ImageDraw, ImageFont
import sys

CHARACTER_WIDTH=14
CHARACTER_HEIGHT=25


class image_to_text:

    emission_probabilities = {}
    initial_probabilities = {}
    transition_probabilities = {}

    #initialising constructors for the different probability calculation
    def __init__(self, trn_letters, tst_letters, train_text_filename):
        self.train_letters = trn_letters
        self.test_letters = tst_letters
        self.train_text_filename = train_text_filename

    def calculate_matching_pixels(self, trn_letter, tst_letter):
        matching_asterisk_count = 0
        matching_white_pixel_count = 0
        nonmatching_asterisk_count = 0
        nonmatching_white_pixel_count = 0
        total_pixels = 0
        for index in range(len(tst_letter)):
            x = tst_letter[index]
            y = trn_letter[index]
            for i in range(len(x)):
                total_pixels += 1
                if x[i] == y[i] and y[i] == '*':
                    matching_asterisk_count += 1
                elif x[i] == y[i] and y[i] == ' ':
                    matching_white_pixel_count += 1
                elif y[i] == '*':
                    nonmatching_asterisk_count += 1
                elif y[i] == ' ':
                    nonmatching_white_pixel_count += 1
        return {
            'matching_asterisk': matching_asterisk_count,
            'matching_white_pixel': matching_white_pixel_count,
            'nonmatching_asterisk': nonmatching_asterisk_count,
            'nonmatching_white_pixel': nonmatching_white_pixel_count,
            'total_pixels': total_pixels
        }

    def calculate_emission_probabilites(self):
        # calculate number of pixels and asterisk that are populated in test letters
        test_asterisks_count = 0
        test_total_pixels = 0
        for cur_letter in self.test_letters:
            for char in cur_letter:
                test_total_pixels += 1
                if char == '*':
                    test_asterisks_count += 1

        test_avg_asterisks = test_asterisks_count / float(test_total_pixels)

        # calculate number of pixels and asterisk that are populated in train letters
        train_asterisks_count = 0
        train_total_pixels = 0
        for cur_letter in self.train_letters:
            for char in self.train_letters[cur_letter]:
                train_total_pixels += 1
                if char == '*':
                    train_asterisks_count += 1

        train_avg_asterisks = train_asterisks_count / float(train_total_pixels)

        # calculate emission probabilities
        for test_letter_index in range(len(self.test_letters)):
            # for each test letter, we calculate number of matching black and white pixels between each training letter
            # end the test letter under consideration
            self.emission_probabilities[test_letter_index] = {}
            for train_letter in train_letters:
                match_result = self.calculate_matching_pixels(train_letters[train_letter], self.test_letters[test_letter_index])
                if test_avg_asterisks > train_avg_asterisks:
                    self.emission_probabilities[test_letter_index][train_letter] = math.pow(0.85, match_result['matching_asterisk']) * math.pow(0.8,match_result['matching_white_pixel']) * math.pow(0.2, match_result['nonmatching_asterisk']) * math.pow(0.15, match_result['nonmatching_white_pixel'])
                else:
                    self.emission_probabilities[test_letter_index][train_letter] = math.pow(0.99, match_result['matching_asterisk']) * math.pow(0.6, match_result['matching_white_pixel']) * math.pow(0.4, match_result['nonmatching_asterisk']) * math.pow(0.01, match_result['nonmatching_white_pixel'])


    def calculate_initial_probabilities(self):
        train_text_file = open(self.train_text_filename)
        count_map = {}
        total = 0
        for train_text_line in train_text_file:
            ch = train_text_line[0]
            if ch not in count_map:
                count_map[ch] = 1
            else:
                count_map[ch] += 1
        for char in count_map:
            self.initial_probabilities[char] = count_map[char] / float(sum(count_map.values()))


    def calculate_transition_probabilities(self):
        train_text_file = open(self.train_text_filename)
        for train_text_line in train_text_file:
            mod_line = ''.join(list(re.sub(r'[&|$|*|;|`|#|@|%|^|~|/|<|>|:|[|\]|{|}|+|=|_]', r'', " ".join([w for w in train_text_line.split()]))))
            if mod_line:
                for index in range(1, len(mod_line)):
                    char = train_text_line[index]
                    prev_char = train_text_line[index - 1]
                    if prev_char in self.transition_probabilities:
                        self.transition_probabilities[prev_char][char] = self.transition_probabilities[prev_char].get(char, 0) + 1
                    else:
                        self.transition_probabilities[prev_char] = {char: 1}
        for char in self.transition_probabilities:
            total = sum(self.transition_probabilities[char].values())
            for ch in self.transition_probabilities[char]:
                self.transition_probabilities[char][ch] /= float(total)


    def simplified_image_to_text(self):
        if len(self.emission_probabilities) == 0:
            self.calculate_emission_probabilites()
        result = ""
        for char in self.emission_probabilities:
            result += "".join(max(self.emission_probabilities[char], key=lambda x: self.emission_probabilities[char][x]))
        return result

    def hmm_image_to_text_v2(self):
        if len(self.initial_probabilities) == 0:
            self.calculate_initial_probabilities()
        if len(self.emission_probabilities) == 0:
            self.calculate_emission_probabilites()
        if len(self.transition_probabilities) == 0:
            self.calculate_transition_probabilities()

        current_state = [None]*128
        previous_state = [None]*128
        for test_letter_index, test_letter in enumerate(self.test_letters):
            for train_letter_index, train_letter in enumerate(self.train_letters):
                if test_letter_index == 0:
                    result = -math.log(self.emission_probabilities[0][train_letter]) - math.log(self.initial_probabilities.get(train_letter, math.pow(10, -8)))
                    current_state[ord(train_letter)] = [result, [train_letter]]
                else:
                    max_heap = []
                    for prev_letter_index, prev_letter in enumerate(self.train_letters):
                        trans_prev_prob = -math.log(
                            self.transition_probabilities.get(prev_letter, {}).get(train_letter, math.pow(10, -8))) + previous_state[ord(prev_letter)][0]
                        max_heap.append([trans_prev_prob, previous_state[ord(prev_letter)][1] + [train_letter]])
                    heapq.heapify(max_heap)
                    max_element = heapq.heappop(max_heap)
                    result = max_element[0] - math.log(self.emission_probabilities[test_letter_index][train_letter])
                    current_state[ord(train_letter)] = [result, max_element[1]]
            previous_state = copy.deepcopy(current_state)
            current_state = [None]*128

        final_result_list = []
        for element in previous_state:
            if element is not None:
                final_result_list.append(element)

        heapq.heapify(final_result_list)
        final_result_index = heapq.heappop(final_result_list)
        return ''.join(final_result_index[1])

def load_letters(fname):
    im = Image.open(fname)
    px = im.load()
    (x_size, y_size) = im.size
    print(im.size)
    print(int(x_size / CHARACTER_WIDTH) * CHARACTER_WIDTH)
    result = []
    for x_beg in range(0, int(x_size / CHARACTER_WIDTH) * CHARACTER_WIDTH, CHARACTER_WIDTH):
        result += [ [ "".join([ '*' if px[x, y] < 1 else ' ' for x in range(x_beg, x_beg+CHARACTER_WIDTH) ]) for y in range(0, CHARACTER_HEIGHT) ], ]
    return result

def load_training_letters(fname):
    TRAIN_LETTERS="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789(),.-!?\"' "
    letter_images = load_letters(fname)
    return { TRAIN_LETTERS[i]: letter_images[i] for i in range(0, len(TRAIN_LETTERS) ) }

#####
# main program
if len(sys.argv) != 4:
    raise Exception("Usage: python3 ./image2text.py train-image-file.png train-text.txt test-image-file.png")

(train_img_fname, train_txt_fname, test_img_fname) = sys.argv[1:]
train_letters = load_training_letters(train_img_fname)
test_letters = load_letters(test_img_fname)


img_to_text = image_to_text(train_letters, test_letters, train_txt_fname)
print("Simplified Naive Bayes: ", img_to_text.simplified_image_to_text())
print("HMM Map : ", img_to_text.hmm_image_to_text_v2())
# print('simple string')

