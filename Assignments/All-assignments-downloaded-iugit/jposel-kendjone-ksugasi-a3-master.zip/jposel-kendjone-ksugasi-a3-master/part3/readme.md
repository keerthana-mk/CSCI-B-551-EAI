# Part 3 - Reading text

## Problem Statement
The aim is to read the text from a noisy image. This is similar to Optical Character Recognition (OCR). Here we recognize the text character by character.

## Approach

The overall approach is to calculate the probability of the 
black dots(*) and white space in the image pixel by pixel which is defined to be 14 * 25 dimensions.
We can read the text using two approached:
1. Simple Naive Bayes
2. Hidden Markov models using MAP.

### Naive Bayes:

In this approach we calculate the emission probabilities of the characters in an emission probability dictionary for all the characters possible 
i.e. Uppercase alphabets, lowercase alphabets,digits, special characters or punctuations.
We return the output of the characters with the maximum probability.
~~~
 result += "".join(max(self.emission_probabilities[char], key=lambda x: self.emission_probabilities[char][x]))
~~~
### HMM using MAP:
HMM is a special case of Bayes net. In HMM the probability of transitioning 
to next state depends on the current state.It has 3 parts:
* Initial Probability
* Transition Probability
* Emission Probability

We use MAP (Maximum A Posteriori) to find the text present in the image. MAP uses Viterbi decoding / Algorithm to 
determine the posterior probability of an event occurring.
To achieve the above goal we try to maximize the probability of current state character given an observed character.
We find the probability of each character and pick the char with the highest Probability.
HMM calculates that the probability of a character being the next character based on the probability of its previous set of characters observed.

#### *hmm_image_to_text_v2()*:
In the *hmm_image_to_text_v2()* we use bc.train from part1 as the training text. Since it has POS tagging 
we are considering only the alternate words in the file.We calculate the initial, transition and emission probabilities 
if not calculated. We initialise 2 lists of 128 characters each as a placeholder for the ASCII characters.
For every test letter in the test letter list we iterate through the train letter list and calculate the probability of each character. If the test character is 
has indexed 0 ie first character, then the probability is calculated using the emission and initial probability and store it in current state list. If not index 0,
then we calculate the result using transition probability such that as follows.
* For every training letter we calculate the transition probability from the previous selected letter.
* Once the transition probability for every training letter is calculated, the training letter with the highest transition probability is chosen. 

This is realised using **Max heaps**. We take the negative log of the probability to avoid underflow, and it also helps us realise max heap
as general implementation of heaps in python is done through min heap. Because of the taking the negative log of the probabilities it would be easier to get the desired highest probability value.
We pop the result from the heap and to form the string of recognised text from the image.

### Other Utility functions

#### 1. *calculate_matching_pixels(train_letters, test_letters)*
This function is used to calculate the number of matching and non-matching letters (*) and matching and non-matching pixels 
of white spaces for both the training and the testing set. It returns a dictionary of count of matching_asterisk,matching_white_pixel,
nonmatching_asterisk, nonmatching_white_pixel and total_pixels.

#### 2. *calculate_initial_probabilities()*
We calculate the initial probability on the training set of letter from the train file.For every 
first character of a sentence we find the count of the character and return the probability which is the initial probability.
~~~
 self.initial_probabilities[char] = count_map[char] / float(sum(count_map.values()))
~~~

#### 3. *calculate_transition_probabilities()*
In this function we iterate through the training set and remove the characters which is not required.
We store the previous and current test letter and calculate the probability from transitioning from one character to all other characters.

#### 4. *calculate_emission_probabilites()*
In this function we calculate average number of pixels and asterisk that are populated in test letters and train letters.
For each test letter, we calculate number of matching black and white pixels between each training letter.
We observe some values fixed which are the priors for match and non-matching characters. These values are decided after experimenting with different values.
Its idea is to use different probability weights for different pixel values  and the that density of the image will be a factor in deciding
the weights we assign to matching & non-matching pixels and black & white space pixels.

### Observations
We can observe that HMM model reads the text more accurately than Naive Bayes. 


## References:
1. https://medium.com/@phylypo/nlp-text-segmentation-using-hidden-markov-model-f238743d87eb
2. https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-047-computational-biology-fall-2015/lectures_slides/MIT6_047F15_Lecture05.pdf
3. https://courses.cs.washington.edu/courses/cse546/12wi/assignments/classification/classification.html