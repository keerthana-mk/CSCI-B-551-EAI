# a2 - Kristen Hlava, Keerthana Sugasi, Lavanya Nesarikar

## Part 1 [Kristen Hlava]

This part of the project was executed in multiple parts. First, time needed to be spent just getting the basic movement mechanics of the game working. 
Luckily, some of the grid based movement was similar to what was done in arrange_pichus from assignment 0, so I was able to borrow some of my old code from that (especially the annoying diagonals for the Raichus). The two assignments stored their grids in very different formats though (linear string vs 2D array), so I had some converting to do to make this assignments
representation the same as a0, and then also be able to convert it back. Pichus were easy enough to implement since they only had 4 possible moves each (diagonal left/right and diagonal jump left/right), but pikachus turned out to be a pain. I eventually realized that left/right moves were the same for both players and at least only had to duplicate the forward moves due to opposing directions, but it still felt like a LOT of repeated code. This also left a lot of room for off-by-one/indexing errors, which seemed to keep popping up as I continued to test this program. Raichu movement was the same for either player so that was able to be condensed into one function with the given player passed in.


Once the general movement patterns were in place, actually playing the game was the next hurdle to jump over. I started with thinking of how to evaluate one move as better than the others. The winning state was once the opponent had no pieces left, so I started with that, knowing it would need to be expanded upon. Based on class notes, the minimax algorithm seemed to be the best bet for implementing this game, and the given player wants to maximize their potential moves and the opposing player wants to minimize that. I was struggling a bit with how to get started on the minimax algorithm, and was searching around the internet for some basic implementations. The primary one I used for minimax was: https://tonypoer.io/2016/10/28/implementing-minimax-and-alpha-beta-pruning-using-python/ , which I followed fairly closely with the exception of not running it as a class and passing variables with the self keyword, and obviously different win conditions and evaluation functions. 


My first implementation of minimax had a few big issues. It resulted in a seemingly infinite loop (or was just running long enough over enough state spaces that it was the recursion was killing itself), because I wasn't sure the best way to stop it besides finding a win state. Win states were incredibly far down the game tree from most initial boards. I eventually added in parameters to specify how deep into the game tree the algorithm could travel before being forced to return back. 
Another issue was I thought I needed to be returning the boards at each step to keep track of what boards went with was min/max values, but this led to some grossly inaccurate next moves being returned at the end. The inaccurate boards were because possible moves several layers down in the tree were being returned up (i.e, several moves in the future, not the NEXT move). By adding in a few extra lines to the minimax function before and after calling the "maximum" function, I was able to save the scores and their associated boards for the next moves directly from the initial board. 

The last big issue was timing. Knowing that tests would be run with about 30 seconds max, trying to figure out the best depth to run through minimax and return the best possible value was proving to be a bit tricky (a depth of 3 was already taking longer than 30 seconds). Looking back through the notes, I decided to try and implement alpha-beta pruning to minimize the number of nodes in the game tree. It seemed to help a bit, so a depth of 3 was no longer unreasonable, but 4 still took quite awhile. Based on print statement debugging, nodes were definitely being pruned, but I'm not convinced I implemented this entirely correctly (it seemed too easy how I did it).


Once the code for testing was posted, running through that repeatedly found several incorrect movement implementations: usually around jumps, and specifically lots of Raichu errors. I ended up completely rewriting the code for the diagonals (which I borrowed from a0 anyways) because that was easier than debugging what I had. The nexted loops for handling jumps proved to be what was usually tripping me up, either terminating at the wrong time or forgetting to break the outer loop (thus resulting in additional states than expected)

Lastly, once I solved all the movement bugs, it came time to tune the evaluation function to try and make my player as strong as possible. The factors I included in this evaluation were (in order of weight):

- Differential in number of total pieces between player and opponent
- Difference in number of Raichus
- Difference in number of Pikachus
- Difference in number of Pichus
- A Location Score (calculated as a way to incentivize pichus to move forward and hopefully become Raichus, and prevent raichus from being in a location where they could be jumped)

This tuning process took quite awhile and probably will never be perfect. I was really struggling to even win consistently against the given "random" opponent.

## Part 2 : The Game of Quintris  [Keerthana Sugasi,Lavanya Nesarikar]

This program implements a computer player for Quintris game which scores as high as possible by placing the tiles optimally. 

### Approach:

The Quintris game is playing by moving(rotation and position)the tetris(tiles) that completes a line. 
Score is assigned on completing the lines by filling with tile blocks. The game end when the tiles or teris pieces 
reach the topmost row or touch the sky.
There are different heuristics considered here to place the tiles optimally in it position to achieve the maximum score.
#### Heuristics:
1) **Aggregate Height:** It is the sum of the heights of each column in the board. It also tells the highest point of the board. This value should be minimised because then we can allow more pieces to be accommodated in the board. 
2) **Completed lines:** Number of complete lines in the board. These values should be maximised because it gives the clears up space and 
    gives room for new tiles coming in.This determines the score of the player as well.
3) **Number of Holes:** A hole is identified as a space surrounded by tetris blocks on all sides.This value should be minimised as much as possible
    because this can cause the board to get filled with tetris easily and quickly.
4) **Bumpiness:** it represents wells in the boards where one column is empty completely.
     If a well were to be covered, all the rows which the well spans will be hard to clear.
    This value needs to be minimised to ensure the top of grid is uniform.

### Implementation

All possible moves are calculated as follows:

For each current piece and next available piece there are 8 possible alignments i.e
1. piece can be considered as it is
2. Piece can be rotated for 90 degree once or rotated twice (180 degree) or rotated thrice (270 degrees)
3. Original piece can be horizontally flipped
4. Horizontally flipped piece can be rotated for 90 degree once or rotated twice (180 degree) or rotated thrice (270 degrees)

And each of the alignments can be placed in every possible column between 0 and Board.col-Number of col in the tile.
Hence, 
> total number of alignments placements per piece = number of alignments * number of possible columns for placement
>  where  number of alignments * number of possible columns for placement = 8 * n-m+1 
> where n=number of board columns and m = number of columns in the piece.

For each of the above moves we calculate the score after the piece is placed in the board using the function *Evaluate(board_state)*.
We append the alignment, the column which was chosen, the score of the board into a list.Once we have calculated this information for all the possible combinations
of alignments and columns we select the combination that generates the highest score. 

Finally, the move is calculated as alignments followed by the left or right movements required to be made to place tile from its original position to the desired column.

#### Score Evaluation:
Given a board state we calculate the heuristics mentioned above. For each heuristic a weight has been assigned to indicate to
the AI whether the board state is encouraging or not. A negative weight assigned indicates that 
it is an undesirable state whereas a positive weight suggest the Ai that it is heading in the desired direction.
For example, bumpiness heuristic tells the unevenness in the board and a good state for tetris game requires an even surfaced board.
Hence, bumpiness is assigned a negative weight.

Finally, score of a given state is calculated as weighted sum of all the heuristics.Generally the more positive the score is, the
better the board state is.

### References:
* https://codemyroad.wordpress.com/2013/04/14/tetris-ai-the-near-perfect-player/
* https://www.youtube.com/watch?v=ptUXxWumxfE

# Part 3: Truth be Told                          [By Keerthana Sugasi]
## **Problem Statement:**
Classify Hotel reviews using Naive Bayes Classifier.The two types of classes are "**Truthful**" and "**Deceptive**".

## **Approach:**

### 1. **Naive Bayes Classifier**
Naive Bayes Classifier predicts the class to which a review belongs through calculating the conditional probability P (class = j | review = d). It uses the Bayes rule to calculate this conditional probability. It is as following
<center>P (A | B) = P (B|A)P (A)/P (B)</center>
Applying the Bayes rule, we can find the conditional probability as:
<center>P(class=A|review=d) = P(review=d|class=A) P(class=A) / P(review=d)</center>

We find this conditional probability for each of the class A, and compare the probabilities. The class for which this
conditional probability will be the highest against the class B will be the one we predict.
<center>P (A| w<sub>1</sub>, w<sub>2</sub>,... w<sub>n</sub>) / P (B| w<sub>1</sub>, w<sub>2</sub>,... w<sub>n</sub> ) > 1</center> where review consists of  w<sub>1</sub>, w<sub>2</sub>,... w<sub>n</sub>.
                
Since we compare these conditional probabilities we can safely ignore the denominator i.e P(review  = d)

1.1 **Calculating P(reviews = d | class = A):**

P(review = d | class = A) is probability of words in review d being present in class A.
In order to calculate P (document = d | class = j), we do the following:

1. Split the reviews into words.
2. Calculate the probability of each word occurring in a review given the class as 
    <center>frequency of word / total number of words in class A</center>
3. Multiply these probabilities of words in review given the class, to get the probability of review given class. We can do this,
because **Naive bayes assumes conditional independence.**

1.2  **Calculating P(class = A):**

number of reviews in class A / total reviews

Once we calculate the above probabilities, we can calculate P (class = A|review = d) using Bayes rule for each
of the classes (truthful and deceptive). Then we can compare them to come up with a prediction.

### 2. Smoothing Parameters
If a particular word has not occurred at all in training set for a given class, during prediction, it will cause the product
of probabilities to be 0. Irrespective of how likely that review would have been predicted for that given class, due
to this word its conditional probability becomes 0.

This is a very likely scenario in real world. In order to circumvent this and improve predictions, we add smoothing
parameters. Smoothing parameters allows us to express prior knowledge about the data. In our case, it adds a non
zero positive value to the word frequencies that will ensure the cases of zero probabilities will be handled.
With a smoothing parameter *m*.

By adding the smoothing parameter, our probability calculation for a word in a class will change to the following:
    
P(word|class) = (#frequency_of_word + m)/(#_total_no_words + |v|*m) where m is the smoothing parameter and v is the vocabulary of class.


### 3. Data Processing
Following data preprocessing has been applied both the training and test sets before training the model.
1. **Punctuation removal:** From each of the document, all the punctuations such as [!, ?, #, @, &, .] etc have been
removed. This will make words ’Happy!!!’, ’Happy!?’, ’Happy.’ all the same as ’Happy’.
2. **Convert to lower case:** All the documents have been converted to lower case. This will make words like
’Happy’, ’HAPPY’, ’happy’ all same as ’happy’.

With preprocessing, we concentrate usages of same words in conjunction with punctuations, different cases. This
will contribute to increase frequency and subsequently the likelihood probabilities.
### 3. Implementation

1. <b><i>load_file():</i></b>
   The *load_file()* takes the Training and testing file and parses the files into labels, classes and objects (list of reviews).


2. <b><i>calculateFreq():</i></b>
   The *calculateFreq()* takes the training data as input and calculates the frequency of the words in each reviews.We create two dictionary maps 
   * truthful{} map
   * deceptive{} map
   
   The words in truthful reviews train data are classified into truthful map and those in deceptive review is
   classified into deceptive map. We also calculate the total number of truthful and deceptive reviews. Also the sum of frequency of all words in the truthful and deceptive maps is calculated.
Together, these values form our Model, and this model is returned to the classifier.


3. <b><i>classifier():</i></b>
   The *classifier()* takes the training data and test data as input and returns the predictions of a review in the test data.
   The predict() takes each review in test data and calculates their conditional probabilities for each class to decide if the review is truth or deceptive using the model.


4. <b><i>predict():</i></b>
   The *predicts()* takes a review, model and smoothing parameter as input and returns a prediction. Smoothing parameters helps us express the prior knowledge on the data. For example, a value of 1 for smoothing parameter suggests that we know for a fact that every single word occurs atleast once in our training data. This will help us deal with cases where we come across a word in test data or real data, that we have not yet seen during training.
For every word in the review, we calculate the probability of word given the class. Product of these probabilities for all words in review, will give the conditional probability P(review|class) (likelihood), we can do this since Naive Bayes assumes conditional independence.
We then calculate the prior probability as ratio of documents of given class to total documents. Then finally, the posterior probability will be calculated as product of likelihood and prior probabilities. Once we have calculated posterior probability for all classes, we predict the class with the highest probability.

Note: We are taking the log of the probabilities as the product result using Naive Bayes might be very small values and cause an underflow and hence may lead to incorrect results.
   ~~~
    if sum_P1 >= sum_P2:
        return 'truthful'
    else:
        return 'deceptive'
   ~~~
   
### 4. Results and Observations:
   **The final accuracy obtained from model using Naive Bayes is 86.5%**
#### Observations:
* As mentioned in the **data processing section 3**, we have preprocessed the data to get the accuracy of 86.5%. Without preprocessing the data we get a accuracy of 82.75%.By preprocessing the data we observe a increase in
accuracy by almost 3.75%.
* The concept of **smoothing parameters** in section 2, handles the cases where the words encountered in the 
   test data set was not found in the training set. On trying on different range of smoothing parameters between 0.1,...,1. The maximum accuracy was attained at 0.2.

   For small values of smoothing parameter m, the accuracy of model increase significantly. This increase in accuracy is attributed to elimination of zero probability cases, where some
   word is missing from the training data. Introduction of small smoothing parameter will ensure that the
   contributions of other words of review to the likelihood probability does not go in vain, while making sure that
   absence of this word is also accounted for.

### References:
1. https://www.kdnuggets.com/2020/07/spam-filter-python-naive-bayes-scratch.html
2. https://towardsdatascience.com/naive-bayes-classifier-how-to-successfully-use-it-in-python-ecf76a995069

