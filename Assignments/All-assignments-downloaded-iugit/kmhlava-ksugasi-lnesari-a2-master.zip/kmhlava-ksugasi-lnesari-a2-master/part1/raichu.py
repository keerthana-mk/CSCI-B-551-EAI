#
# raichu.py : Play the game of Raichu
#
# Kristen Hlava [kmhlava]
# Keerthana Sugasi [ksugasi]
# Lavanya Nesarikar [lnesari]
#
# Based on skeleton code by D. Crandall, Oct 2021
#
import sys
import time
import copy
import random

def board_to_string(board, N):
    return "\n".join(board[i:i+N] for i in range(0, len(board), N))

def board_to_array(board, N):
    #convert string to a 2D array
    #2D array easier to work with coordinates
    new_board = []
    for i in range(len(board)):
        if i%N ==0:
            sub = board[i:i+N]
            lst = []
            for j in sub:
                lst.append(j)
            new_board.append(lst)
    return new_board

def array_to_board(board, N):
    #Convert 2D array back to string to be
    #compatible with expected readout
    new_board = ""
    for i in range(0,N):
        for j in range(0,N):
            #new_array.append(board[i][j])
            new_board += board[i][j]
    
    return new_board

def count_pieces(board, player):
    # Count total # of pieces on board for each player
    # separated by type for evaluation function
    if(player == "w"):
        pichu = sum([ row.count('w') for row in board ] )
        pikachu = sum([ row.count('W') for row in board ] )
        raichu = sum([ row.count('@') for row in board ] )
    else:
        pichu = sum([ row.count('b') for row in board ] )
        pikachu = sum([ row.count('B') for row in board ] )
        raichu = sum([ row.count('$') for row in board ] )
    
    return [pichu,pikachu,raichu]

def get_piece_locs(board, piece):
    #find any locations on the board marked with a specific piece
    pieces = []
    for r in range(0,len(board)):
        for c in range(0,len(board[0])):
            if board[r][c] == piece :
                pieces.append((r,c))
    return pieces

def poss_moves_pichu_w(board, N):
    #Find all possible next moves for pichu pieces on team W
    moves = []
    pichus = get_piece_locs(board, "w")
    for p in pichus:
        row = p[0]
        col = p[1]
        #regular forward diagonal moves
        if row <= (N-2):
            if col <= (N-2):
                try:
                    if board[row+1][col+1] == ".":
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        if(row == N-2):
                            #reached final row, convert to Raichu
                            new_board[row+1][col+1] = "@"
                        else:
                            new_board[row+1][col+1] = "w"
                        moves.append(new_board)
                except IndexError:
                    continue
            if col >= 1 and col <= N-1:
                try:
                    if board[row+1][col-1] == ".":
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        if(row == N-2):
                            #reached final row, convert to Raichu
                            new_board[row+1][col-1] = "@"
                        else:
                            new_board[row+1][col-1] = "w"
                        moves.append(new_board)
                except IndexError:
                    continue
        #jumping diagonal moves
        if row <= (N-3):
            if col <= (N-3):
                #check if opponent pichu
                try:
                    if board[row+1][col+1] == "b":
                        #check if space free after opponent
                            if board[row+2][col+2] == ".":
                                new_board = copy.deepcopy(board)
                                new_board[row][col] = "."
                                new_board[row+1][col+1] = "."
                                if(row+2 == N-1):
                                    #reached final row, convert to Raichu
                                    new_board[row+2][col+2] = "@"
                                else:
                                    new_board[row+2][col+2] = "w"
                                moves.append(new_board)
                except IndexError:
                    continue
            if col >= 2 and col <= (N-1):
                try:
                    if board[row+1][col-1] == "b":
                            if board[row+2][col-2] == ".":
                                new_board = copy.deepcopy(board)
                                new_board[row][col] = "."
                                new_board[row+1][col-1] = "."
                                if(row+2 == N-1):
                                    new_board[row+2][col-2] = "@"
                                else:
                                    new_board[row+2][col-2] = "w"
                                moves.append(new_board)
                except IndexError:
                    continue
    return list(filter(None, moves)) #filter out any moves that couldnt exist due to index Errors

def poss_moves_pichu_b(board, N):
    #find all next possible moves for pichus on team B
    moves = []
    pichus = get_piece_locs(board, "b")
    for p in pichus:
        row = p[0]
        col = p[1]
        #regular diagonal moves
        if row >= 1:
            if col <= N-2:
                try:
                    if board[row-1][col+1] == ".":
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        if (row == 1):
                            #reached final row, convert to Raichu
                            new_board[row-1][col+1] = "$"
                        else:
                            new_board[row-1][col+1] = "b"
                        moves.append(new_board)
                except IndexError:
                    continue
            if col >= 1:
                try:
                    if board[row-1][col-1] == ".":
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        if (row == 1):
                            #reached final row, convert to Raichu
                            new_board[row-1][col-1] = "$"
                        else:
                            new_board[row-1][col-1] = "b"
                        moves.append(new_board)
                except IndexError:
                    continue
        #jumping over opponent moves
        if row >= 2:
            if col < N-2:
                #check if opponent pichu
                try:
                    if board[row-1][col+1] == "w":
                        #check if available spot after opponent
                            if board[row-2][col+2] == ".":
                                new_board = copy.deepcopy(board)
                                new_board[row][col] = "."
                                new_board[row-1][col+1] = "."
                                if (row-2 == 0):
                                    #reached final row, convert to Raichu
                                    new_board[row-2][col+2] = "$"
                                else:
                                    new_board[row-2][col+2] = "b"
                                moves.append(new_board)
                except IndexError:
                    continue
            if col >= 2:
                try:
                    if board[row-1][col-1] == "w":
                            if board[row-2][col-2] == ".":
                                new_board = copy.deepcopy(board)
                                new_board[row][col] = "."
                                new_board[row-1][col-1] = "."
                                if (row-2 == 0):
                                    #reached final row, convert to Raichu
                                    new_board[row-2][col-2] = "$"
                                else:
                                    new_board[row-2][col-2] = "b"
                                moves.append(new_board)
                except IndexError:
                    continue
    return list(filter(None, moves)) #remove moves that aren't possible due to IndexErrors

def pikachu_right(board, row, col, spaces, player):
    #move a pikachu piece right a certain number of spaces
    #regular moves: 1 or 2 spaces
    #jumping moves: 2 or 3 spaces

    #figure out which opponent pieces eligible to jump
    if player == "W":
        opp = ["b", "B"]
    else:
        opp = ["w","W"]

    new_col = col +spaces
    if(new_col == len(board)-1):
        return
    #regular move "spaces" number of spaces
    if board[row][new_col] == ".":
        if spaces == 1:
            new_board = copy.deepcopy(board)
            new_board[row][col] = "."
            new_board[row][new_col] = player
            return new_board
        else:
            if board[row][col+1] == ".":
                #print("B")
                new_board = copy.deepcopy(board)
                new_board[row][col] = "."
                new_board[row][new_col] = player
                return new_board
    #jumping move "spaces" number of spaces
    if(new_col +1 == len(board)):
        return
    elif board[row][new_col] in opp:
        if spaces ==1:
            try:
                if board[row][new_col+1] == ".":
                    #print("C")
                    new_board = copy.deepcopy(board)
                    new_board[row][col] = "."
                    new_board[row][new_col] = "."
                    new_board[row][new_col+1] = player
                    return new_board
            except IndexError:
                #Index error was cleaner than a bajillion if statements... seems to be working?
                return None
        else:
            try:
                if board[row][new_col+1] == ".":
                    if board[row][col+1] == ".":
                        #print("D")
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        new_board[row][new_col] = "."
                        new_board[row][new_col+1] = player
                        return new_board
            except IndexError:
                #Index error was cleaner than a bajillion if statements... seems to be working?
                return None

def pikachu_left(board, row, col, spaces, player):
    #move a pikachu piece left a certain number of spaces
    #regular moves: 1 or 2 spaces
    #jumping moves: 2 or 3 spaces

    #figure out which opponent pieces eligible to jump
    if player == "W":
        opp = ["b", "B"]
    else:
        opp = ["w","W"]

    new_col = col - spaces
    if new_col <0:
        #print("fail")
        return None
    #regular move "spaces" number of spaces
    if board[row][new_col] == ".":
        if spaces == 1:
            #print("E")
            new_board = copy.deepcopy(board)
            new_board[row][col] = "."
            new_board[row][new_col] = player
            return new_board
        else:
            if board[row][col-1] == ".":
                #print("F")
                new_board = copy.deepcopy(board)
                new_board[row][col] = "."
                new_board[row][col-1] = "."
                new_board[row][new_col] = player
                return new_board

    #jumping move "spaces" number of spaces
    elif board[row][new_col] in opp:
        if(new_col -1 <0):
            #print("return")
            return
        try:
            if board[row][col-1] == ".":
                if spaces == 1:
                    #print("G")
                    new_board = copy.deepcopy(board)
                    new_board[row][col] = "."
                    new_board[row][new_col] = "."
                    new_board[row][new_col-1] = player
                    return new_board
                else:
                    if board[row][new_col-1] == ".":
                        #print("H")
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        new_board[row][new_col] = "."
                        new_board[row][new_col-1] = player
                        return new_board

        except IndexError:
            #Index error was cleaner than a bajillion if statements... seems to be working?
            return None

#due to opposite directions, forward needed to be split by player
def pikachu_forward_w(board, row, col, spaces):
    #move a pikachu piece forward a certain number of spaces
    #regular moves: 1 or 2 spaces
    #jumping moves: 2 or 3 spaces

    #regular move forward
    if board[row+spaces][col] == ".":
        if spaces ==1:
            #print("I")
            new_board = copy.deepcopy(board)
            new_board[row][col] = "."
            if (row+spaces == N-1):
                #reached final row, convert to raichu
                new_board[row+spaces][col] = "@"
            else:
                new_board[row+spaces][col] = "W"
            return new_board
        else:
            if board[row+1][col] == ".":
                #print("J")
                new_board = copy.deepcopy(board)
                new_board[row][col] = "."
                if (row+spaces == N-1):
                    #reached final row, convert to raichu
                    new_board[row+spaces][col] = "@"
                else:
                    new_board[row+spaces][col] = "W"
                return new_board
    #jumping move forward
    elif board[row+spaces][col] in ["b","B"]:
        try:
            if board[row+spaces+1][col] == ".":
                if spaces ==1:
                    #print("K")
                    new_board = copy.deepcopy(board)
                    new_board[row][col] = "."
                    new_board[row+spaces][col] = "."
                    if(row+spaces+1 == N-1):
                        #reached final row, convert to raichu
                        new_board[row+spaces+1][col] = "@"
                    else:
                        new_board[row+spaces+1][col] = "W"
                    return new_board
                else:
                    if board[row + 1][col] == ".":
                        #print("L")
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        new_board[row+spaces][col] = "."
                        if(row+spaces+1 == N-1):
                            #reached final row, convert to raichu
                            new_board[row+spaces+1][col] = "@"
                        else:
                            new_board[row+spaces+1][col] = "W"
                        return new_board
        except IndexError:
            return None

def pikachu_forward_b(board, row, col, spaces):
    #move a pikachu piece forward a certain number of spaces
    #regular moves: 1 or 2 spaces
    #jumping moves: 2 or 3 spaces

    #regular move forward
    if board[row-spaces][col] == ".":
        if spaces ==1:
            new_board = copy.deepcopy(board)
            new_board[row][col] = "."
            if(row-spaces == 0):
                #reached last row, convert to raichu
                new_board[row-spaces][col] = "$"
            else:
                new_board[row-spaces][col] = "B"
            return new_board
        else:
            if board[row-1][col] == ".":
                new_board = copy.deepcopy(board)
                new_board[row][col] = "."
                if(row-spaces == 0):
                    #reached last row, convert to raichu
                    new_board[row-spaces][col] = "$"
                else:
                    new_board[row-spaces][col] = "B"
                return new_board

    #jumping move forward
    elif board[row-spaces][col] in ["w","W"]:
            try:
                if board[row-spaces-1][col] == ".":
                    if spaces ==1:
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        new_board[row-spaces][col] = "."
                        if(row-spaces-1 == 0):
                            #reached last row, convert to raichu
                            new_board[row-spaces-1][col] = "$"
                        else:
                            new_board[row-spaces-1][col] = "B"
                        return new_board
                    else:
                        if board[row-1][col] == ".":
                            new_board = copy.deepcopy(board)
                            new_board[row][col] = "."
                            new_board[row-spaces][col] = "."
                            if(row-spaces-1 == 0):
                                #reached last row, convert to raichu
                                new_board[row-spaces-1][col] = "$"
                            else:
                                new_board[row-spaces-1][col] = "B"
                            return new_board
            except IndexError:
                return None

def poss_moves_pikachu_w(board, N):
    #Function to find all possible moves for pikachu on team W
    #making use of forward/right/left subfunctions to avoid repeated
    #code with all the edge case if statements

    moves = []
    pikachus = get_piece_locs(board, "W")
    for p in pikachus:
        row = p[0]
        col = p[1]
        if row <= N-2:
            if col == 0:
                #can move right or forward
                # right
                moves.append(pikachu_right(board,row,col,1, "W")) #1 space/ 2spaces with jump
                moves.append(pikachu_right(board,row,col,2, "W")) #2 space/ 3spaces with jump
                # forward
                moves.append(pikachu_forward_w(board,row,col,1)) #1 space
                if row < N-2:
                    moves.append(pikachu_forward_w(board,row,col,2)) #if room, try 2 spaces

            if col > 0 and col <= N-2:
                #can move right left and forward
                # right
                moves.append(pikachu_right(board,row,col,1, "W")) #1 space/ 2spaces with jump
                if col <= N-3:
                    moves.append(pikachu_right(board,row,col,2, "W")) #2 space/ 3spaces with jump
                # forward
                moves.append(pikachu_forward_w(board,row,col,1)) #1 space/ 2spaces with jump
                if row < N-2:
                    moves.append(pikachu_forward_w(board,row,col,2)) #2 space/ 3spaces with jump
                #left
                moves.append(pikachu_left(board,row,col,1, "W")) #1 space/ 2spaces with jump
                if col > 1:
                    moves.append(pikachu_left(board,row,col,2, "W")) #2 space/ 3spaces with jump

            if col == N-1:
                #can move left and forward
                # forward
                moves.append(pikachu_forward_w(board,row,col,1)) #1 space/ 2spaces with jump
                if row < N-2:
                    moves.append(pikachu_forward_w(board,row,col,2)) #2 space/ 3spaces with jump
                #left
                moves.append(pikachu_left(board,row,col,1, "W")) #1 space/ 2spaces with jump
                moves.append(pikachu_left(board,row,col,2, "W")) #2 space/ 3spaces with jump
    return list(filter(None, moves)) #filter out any moves that couldnt exist due to index Errors

def poss_moves_pikachu_b(board, N):
    #Function to find all possible moves for pikachu on team B
    #making use of forward/right/left subfunctions to avoid repeated
    #code with all the edge case if statements
    moves = []
    pikachus = get_piece_locs(board, "B")
    for p in pikachus:
        row = p[0]
        col = p[1]
        if row >= 1:
            if col == 0:
                #can move right or forward
                # right
                moves.append(pikachu_right(board,row,col,1, "B")) #1 space/ 2spaces with jump
                moves.append(pikachu_right(board,row,col,2, "B")) #2 space/ 3spaces with jump
                # forward
                moves.append(pikachu_forward_b(board,row,col,1)) #1 space/ 2spaces with jump
                if row > 1:
                    moves.append(pikachu_forward_b(board,row,col,2)) #2 space/ 3spaces with jump

            if col > 0 and col <= N-2:
                #can move right left and forward
                # right
                moves.append(pikachu_right(board,row,col,1, "B")) #1 space/ 2spaces with jump
                if col <= N-3:
                    moves.append(pikachu_right(board,row,col,2, "B")) #2 space/ 3spaces with jump
                # forward
                moves.append(pikachu_forward_b(board,row,col,1)) #1 space/ 2spaces with jump
                if row > 1:
                    moves.append(pikachu_forward_b(board,row,col,2)) #2 space/ 3spaces with jump
                #left
                moves.append(pikachu_left(board,row,col,1, "B")) #1 space/ 2spaces with jump
                if col > 1:
                    moves.append(pikachu_left(board,row,col,2, "B")) #2 space/ 3spaces with jump

            if col == N-1:
                #can move left and forward
                # forward
                moves.append(pikachu_forward_b(board,row,col,1)) #1 space/ 2spaces with jump
                if row > 1:
                    moves.append(pikachu_forward_b(board,row,col,2)) #2 space/ 3spaces with jump
                #left
                moves.append(pikachu_left(board,row,col,1, "B")) #1 space/ 2spaces with jump
                moves.append(pikachu_left(board,row,col,2, "B")) #2 space/ 3spaces with jump
    return list(filter(None, moves)) #remove moves that aren't possible due to IndexErrors

def poss_moves_raichu(board, N, player):
    #Find all possible moves for Raichu pieces of either team
    #Essentially a new move for every position in its line of sight
    #additionally any possible jumps
    #line of sight determination taken from kmhlava a0

    moves = []
    raichus = get_piece_locs(board, player)
    #determine opposing players (that can be jumped over)
    if player == "@":
        opp = ["b", "B", "$"]
    else:
        opp = ["w","W", "@"]

    for p in raichus:
        row = p[0]
        col = p[1]
        #print("RAICHU:",row,col)
        #initial moveset is anything in line of sight
        #check right
        #print("POSSIBLE RIGHT MOVES")
        stop_right = False
        for c in range(col +1 ,len(board[0])):
            if stop_right:
                break
            if(board[row][c]=='.'):
                #print("r1")
                new_board = copy.deepcopy(board)
                new_board[row][col] = "."
                new_board[row][c] = player
                moves.append(new_board)
            #jump!
            elif(board[row][c] in opp):
                #print("r2")
                for c2 in range ((c+1), len(board[0])):
                    if(board[row][c2]=='.'):
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        new_board[row][c] = "."
                        new_board[row][c2] = player
                        moves.append(new_board)
                    else:
                        stop_right = True
                        break
                stop_right = True
            else:
                break

        #print("num states after right:", len(moves))

        #check left
        #print("POSSIBLE LEFT MOVES")
        stop_left = False
        for c in range(col-1,-1, -1):
            if(stop_left):
                break
            if(board[row][c]=='.'):
                #print("L1")
                new_board = copy.deepcopy(board)
                new_board[row][col] = "."
                new_board[row][c] = player
                moves.append(new_board)
            #jump!
            elif(board[row][c] in opp):
                #print("L2")
                for c2 in range ((c-1), -1,-1):
                    if(board[row][c2]=='.'):
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        new_board[row][c] = "."
                        new_board[row][c2] = player
                        moves.append(new_board)
                    else:
                        stop_left = True
                        break
                stop_left = True
            else:
                break

        #print("num states after left:", len(moves))

        #check up
        #print("POSSIBLE UP MOVES")
        stop_up = False
        for r in range(row-1,-1, -1):
            if stop_up:
                #print("U4")
                break
            if(board[r][col]=='.'):
                #print("U1")
                new_board = copy.deepcopy(board)
                new_board[row][col] = "."
                new_board[r][col] = player
                moves.append(new_board)
            #jump!
            elif(board[r][col] in opp):
                #print("U2")
                for r2 in range ((r-1), -1, -1):
                    if(board[r2][col]=='.'):
                        #print("U5",row,r,r2,col)
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        new_board[r][col] = "."
                        new_board[r2][col] = player
                        moves.append(new_board)
                    else:
                        #print("U3")
                        stop_up = True
                        break
                stop_up = True
            else:
                break

        #print("num states after up:", len(moves))

        #check down
        #print("POSSIBLE DOWN MOVES")
        stop_down = False
        for r in range(row+1,len(board)):
            if stop_down:
                #print("D4")
                break
            if(board[r][col]=='.'):
                #print("D1")
                new_board = copy.deepcopy(board)
                new_board[row][col] = "."
                new_board[r][col] = player
                moves.append(new_board)
            #jump!
            elif(board[r][col] in opp):
                #print("D3")
                for r2 in range ((r+1), len(board)):
                    if(board[r2][col]=='.'):
                        #print("D2")
                        new_board = copy.deepcopy(board)
                        new_board[row][col] = "."
                        new_board[r][col] = "."
                        new_board[r2][col] = player
                        moves.append(new_board)
                    else:
                        #print("D5")
                        stop_down = True
                        break
                stop_down = True
            else:
                #print("D6")
                break

        #print("num states after down:", len(moves))

        #check diagonal one (up right)
        stop_ur = False
        next_col = col +1
        if(next_col > N-1):
            stop_ur=True
        for r in range(row-1,-1, -1):
            if stop_ur:
                #print("BREAK")
                break
            try:
                if(board[r][next_col]=='.'):
                    #print("A")
                    new_board = copy.deepcopy(board)
                    new_board[row][col] = "."
                    new_board[r][next_col] = player
                    #print(board_to_string(array_to_board(new_board,N),N))
                    moves.append(new_board)
                #jump!
                elif(board[r][next_col] in opp):
                    next_diag = next_col +1
                    for r2 in range ((r-1), -1, -1):
                        if(board[r2][next_diag]=='.'):
                            #print(r2,next_diag)
                            new_board = copy.deepcopy(board)
                            new_board[row][col] = "."
                            new_board[r][next_col] = "."
                            new_board[r2][next_diag] = player
                            #print(board_to_string(array_to_board(new_board,N),N))
                            moves.append(new_board)
                        else:
                            stop_ur = True
                            break
                        next_diag +=1
                        if(next_diag > N-1 or r2 == 0):
                            stop_ur = True
                            break
                else:
                    break
                next_col += 1
            except IndexError:
                break

        #print("num states after up/right:", len(moves))

        #check diagonal two (up left)
        stop_ul = False
        next_col = col -1
        for r in range(row-1,-1, -1):
            if(next_col < 0):
                stop_ul=True
            if stop_ul:
                break
            try:
                if(board[r][next_col]=='.'):
                    #print("DIAG 3")
                    new_board = copy.deepcopy(board)
                    new_board[row][col] = "."
                    new_board[r][next_col] = player
                    moves.append(new_board)
                #jump!
                elif(board[r][next_col] in opp):
                    if next_col ==0:
                        break
                    next_diag = next_col -1
                    if next_diag < 0:
                        break
                    for r2 in range ((r-1), -1, -1):
                        if(board[r2][next_diag]=='.'):
                            #print("DIAG 4")
                            new_board = copy.deepcopy(board)
                            new_board[row][col] = "."
                            new_board[r][next_col] = "."
                            new_board[r2][next_diag] = player
                            moves.append(new_board)
                        else:
                            stop_ul = True
                            break
                        next_diag -=1
                        if(next_diag <= 0 or r2 ==0):
                            #print(next_diag, r2)
                            stop_ul = True
                            break
                else:
                    break
                next_col -= 1
            except IndexError:
                break

        #print("num states after up/left:", len(moves))
        
        #check diagonal three (down right)
        stop_dr = False
        next_col = col +1
        if(next_col > N-1):
            stop_dr=True
        for r in range(row+1, len(board)):
            if stop_dr:
                #print("DR 1")
                break
            try:
                if(board[r][next_col]=='.'):
                    #rint("DIAG 5")
                    new_board = copy.deepcopy(board)
                    new_board[row][col] = "."
                    new_board[r][next_col] = player
                    moves.append(new_board)
                #jump!
                elif(board[r][next_col] in opp):
                    if next_col ==0:
                        break
                    next_diag = next_col +1
                    for r2 in range ((r+1), len(board)):
                        if(board[r2][next_diag]=='.'):
                            #print("DIAG 6")
                            new_board = copy.deepcopy(board)
                            new_board[row][col] = "."
                            new_board[r][next_col] = "."
                            new_board[r2][next_diag] = player
                            moves.append(new_board)
                        else:
                            # print("DR 2")
                            stop_dr = True
                            break
                        next_diag +=1
                        if r2 == N-1 or next_diag > N-1:
                            stop_dr = True
                else:
                    break
                next_col += 1
            except IndexError:
                break

        #print("num states after down/right:", len(moves))

        #check diagonal four (down left)
        stop_dl = False
        next_col = col -1
        for r in range(row+1, len(board)):
            if(next_col < 0):
                stop_dl=True
            if stop_dl:
                break
            try:
                if(board[r][next_col]=='.'):
                    new_board = copy.deepcopy(board)
                    new_board[row][col] = "."
                    new_board[r][next_col] = player
                    moves.append(new_board)
                #jump!
                elif(board[r][next_col] in opp):
                    next_diag = next_col -1
                    for r2 in range ((r+1), len(board)):
                        if(board[r2][next_diag]=='.'):
                            new_board = copy.deepcopy(board)
                            new_board[row][col] = "."
                            new_board[r][next_col] = "."
                            new_board[r2][next_diag] = player
                            moves.append(new_board)
                        else:
                            stop_dl = True
                            break
                        next_diag -=1
                        if r2 == N-1:
                            stop_dl = True
                            break
                        if next_diag <=0 or r2 == N-1:
                            stop_dl=True
                            break
                else:
                    break
                next_col -= 1
            except IndexError:
                break

        #print("num states after down/left:", len(moves))

    
        

    return list(filter(None, moves)) #remove moves that aren't possible due to IndexErrors

def poss_moves_w_player(board, N):
    #find all possible next moves for player W based on current board
    moves = []
    moves += poss_moves_pichu_w(board, N)
    moves += poss_moves_pikachu_w(board, N)
    moves += poss_moves_raichu(board, N, "@")
    random.shuffle(moves) #shuffle to make ties less predictable (always pichus)
    return list(filter(None, moves)) #remove moves that aren't possible due to IndexErrors

def poss_moves_b_player(board, N):
    #find all possible next moves for player B based on current board
    moves = []
    moves += poss_moves_pichu_b(board, N)
    moves += poss_moves_pikachu_b(board, N)
    moves += poss_moves_raichu(board, N, "$")
    random.shuffle(moves) #shuffle to make ties less predictable (always pichus)
    return list(filter(None, moves)) #remove moves that aren't possible due to IndexErrors

def evaluate_move(board, player):
    #calculation for how good a board state is after a move
    w_pieces = count_pieces(board,"w")
    b_pieces = count_pieces(board, "b")

    is_winner = is_game_won(board,player) #is -1 for loss, 0 for draw, 1 for win

    location_score = 0

    # see if current player has a piece advantage (by piece and in total)
    if player == "w":
        pichu_adv = w_pieces[0] - b_pieces[0]
        pikachu_adv = w_pieces[1] - b_pieces[1]
        raichu_adv = w_pieces[2] - b_pieces[2]
        piece_adv = pichu_adv + pikachu_adv + raichu_adv
        #moves = len(poss_moves_w_player(board,len(board)))
        
        #encourage pichus to become raichus?
        pichus = get_piece_locs(board,"w")
        for pichu in pichus:
            if pichu[0] >= (0.5)*len(board):
                location_score +=5
            if pichu[0] >= (0.75)*len(board):
                location_score +=10

        pikachus = get_piece_locs(board,"W")
        for pikachu in pikachus:
            if pikachu[0] >= (0.5)*len(board):
                location_score +=5
            if pikachu[0] >= (0.75)*len(board):
                location_score +=10

        raichus = get_piece_locs(board,"@")
        for raichu in raichus:
            row = raichu[0]
            col = raichu[1]
            for r in range(0,len(board)):
                if row == 0 or row == len(board):
                    location_score += 10
                elif board[r][col]=="$":
                    location_score -= 1000

            for c in range(0, len(board)):
                if col == 0 or col == len(board):
                    location_score += 10
                elif board[row][c]=="$":
                    location_score -= 1000
            

    else:
        pichu_adv = b_pieces[0] - w_pieces[0]
        pikachu_adv = b_pieces[1] - w_pieces[1]
        raichu_adv = b_pieces[2] - w_pieces[2]
        piece_adv = pichu_adv + pikachu_adv + raichu_adv

        pichus = get_piece_locs(board,"b")
        for pichu in pichus:
            if pichu[0] <= (0.5)*len(board):
                location_score +=5
            if pichu[0] <= (0.25)*len(board):
                location_score +=10
        #moves = len(poss_moves_b_player(board,len(board)))

        pikachus = get_piece_locs(board,"B")
        for pikachu in pikachus:
            if pikachu[0] <= (0.5)*len(board):
                location_score +=5
            if pikachu[0] <= (0.25)*len(board):
                location_score +=10

        raichus = get_piece_locs(board,"$")
        for raichu in raichus:
            row = raichu[0]
            col = raichu[1]
            for r in range(0,len(board)):
                if row == 0 or row == len(board):
                    location_score += 10
                elif board[r][col]=="@":
                    location_score -= 1000

            for c in range(0, len(board)):
                if col == 0 or col == len(board):
                    location_score += 10
                elif board[row][c]=="@":
                    location_score -= 1000

    

    #numbers are random, will try to tune these
    #general idea is raichus are more valuable than pikachus which are move valuable than pichus
    #also added just total number of pieces because 10 pichus vs 1 raichu might be a more fair fight than expected?
    return 10000*is_winner + 100*piece_adv + 50*raichu_adv + 5*pikachu_adv + pichu_adv + 5*location_score

def is_game_won(board, player):
    #returns 1 if given player has pieces remaining, and opposing player does not (player wins)
    #returns -1 if given player has no pieces remaining (player loses)
    #returns 0 if both players have pieces remaining (game continues)
    w_pieces = count_pieces(board,"w")
    b_pieces = count_pieces(board, "b")

    if player == "w":
        if (b_pieces[0]+b_pieces[1]+b_pieces[2]==0):
            return 1
        elif (w_pieces[0]+w_pieces[1]+w_pieces[2]==0):
            return -1
        else:
            return 0
    elif player == "b":
        if (b_pieces[0]+b_pieces[1]+b_pieces[2]==0):
            return -1
        elif (w_pieces[0]+w_pieces[1]+w_pieces[2]==0):
            return 1
        else:
            return 0

def minimum(board, N, player, depth, max_depth,a,b):
    #min node for minimax
    # returns minimum value for level in the tree

    #if the game is won by the MIN player, value = -100
    if (is_game_won(board,player)==-1 or is_game_won(board,player)==-1):
        return evaluate_move(board, player)

    #if we have reached the max_depth we want to evaluate, return the move score
    if depth == max_depth:
        return evaluate_move(board, player)

    min_value = 100000000
    #find list of next possible moves
    if player =="w":
        possible_moves = poss_moves_w_player(board, N)
    else:
        possible_moves = poss_moves_b_player(board,N)
    
    for move in possible_moves:
        #find maximum of each next move (the next layer down the tree)
        max_move = maximum(move, N, player, depth+1, max_depth, a, b)
        #take the minimum value of all the maximum values
        min_value = min(min_value, max_move)
        #set beta to the minimum value for a/b pruning
        b = min(b,min_value)
        if(b<=a):
            #beta is less than alpha, therefore the max node above this will never select anything below this node
            break
    
    return min_value

def maximum(board, N, player, depth, max_depth, a , b):
    #max node for minimax
    # returns maximum value for level in the tree

    #if the game is won by the MAX player, value = 100
    if (is_game_won(board,player)==1 or is_game_won(board,player)==-1):
        return evaluate_move(board, player)

    #if we have reached the max_depth we want to evaluate, return the move score
    if depth == max_depth:
        return evaluate_move(board, player)

    max_value = -100000000
    #find list of next possible moves
    if player =="w":
        possible_moves = poss_moves_w_player(board, N)
    else:
        possible_moves = poss_moves_b_player(board, N)

    for move in possible_moves:
        #find minimum of each next move (next layer down the tree)
        min_move = minimum(move, N, player, depth+1, max_depth, a, b)
        #take the maximum value of all the minimum values
        max_value = max(max_value, min_move)
        #set alpha to maximum value for a/b pruning
        a = max(a, max_value)
        if(b<=a):
            #alpha > beta, therefore the min node above this will never select anything below this node
            break

    return max_value

def minimax(board, N, player, max_depth):
    #overall minimax algo
    #returns best move from a specific depth level
    best_value = -1000000
    best_move = None

    #find next moves from beginning board
    if player =="w":
        possible_moves = poss_moves_w_player(board, N)
    else:
        possible_moves = poss_moves_b_player(board,N)

    for move in possible_moves:
        #start minimax recursion with maximum() and ridiculous a/b values
        score = maximum(board, N, player,0,max_depth,-1000000,100000)
        if score > best_value:
            best_value = score
            best_move = move

    return best_move
    
def find_best_move(board, N, player, timelimit):
    #find the best next move!

    #convert board string to my 2D array
    new_board=board_to_array(board,N)
    max_depth = 1 #start with a max depth of 1
    start = time.time() #start the timer!
    while(time.time() - start < timelimit):
       #as long as our time is less than the given time limit, keep running minimax
       #increasing max_depth each time (ideally, each line returned should be better than the last)
      yield(array_to_board(minimax(new_board,N,player, max_depth),N))
      max_depth += 1
    # yield(array_to_board(minimax(new_board,N,player, 3),N))
    # test = poss_moves_raichu(new_board,N,"@")
    # print("NUM STATES", len(test))
    # for t in test:
    #     print(board_to_string(array_to_board(t,N),N))
    #     print("                 ")

if __name__ == "__main__":
    if len(sys.argv) != 5:
        raise Exception("Usage: Raichu.py N player board timelimit")
        
    (_, N, player, board, timelimit) = sys.argv
    N=int(N)
    timelimit=int(timelimit)
    if player not in "wb":
        raise Exception("Invalid player.")

    if len(board) != N*N or 0 in [c in "wb.WB@$" for c in board]:
        raise Exception("Bad board string.")

    print("Searching for best move for " + player + " from board state: \n" + board_to_string(board, N))
    print("Here's what I decided:")
    for new_board in find_best_move(board, N, player, timelimit):
        print(new_board)
