HEURISTIC_AGG_WEIGHT = 'aggregate_weight'
HEURISTIC_NUMBER_OF_HOLES = 'number_holes'
HEURISTIC_BUMPINESS = 'bumpiness'
HEURISTIC_CLEARED_LINES = 'cleared_lines'