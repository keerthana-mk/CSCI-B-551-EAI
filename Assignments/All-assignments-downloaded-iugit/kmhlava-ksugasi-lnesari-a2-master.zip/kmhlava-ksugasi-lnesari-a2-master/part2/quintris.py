# Simple quintris program! v0.2
# D. Crandall, Sept 2021

from AnimatedQuintris import *
from SimpleQuintris import *
from kbinput import *
import time, sys
from quintris_util import *
from constants import *


class HumanPlayer:
    def get_moves(self, quintris):
        print(
            "Type a sequence of moves using: \n  b for move left \n  m for move right \n  n for rotation\n  h for horizontal flip\nThen press enter. E.g.: bbbnn\n")
        moves = input()
        return moves

    def control_game(self, quintris):
        while 1:
            c = get_char_keyboard()
            commands = {"b": quintris.left, "h": quintris.hflip, "n": quintris.rotate, "m": quintris.right,
                        " ": quintris.down}
            commands[c]()


#####
# This is the part you'll want to modify!
# Replace our super simple algorithm with something better
#
class ComputerPlayer:
    # This function should generate a series of commands to move the piece into the "optimal"
    # position. The commands are a string of letters, where b and m represent left and right, respectively,
    # and n rotates. quintris is an object that lets you inspect the board, e.g.:
    #   - quintris.col, quintris.row have the current column and row of the upper-left corner of the
    #     falling piece
    #   - quintris.get_piece() is the current piece, quintris.get_next_piece() is the next piece after that
    #   - quintris.left(), quintris.right(), quintris.down(), and quintris.rotate() can be called to actually
    #     issue game commands
    #   - quintris.get_board() returns the current state of the board, as a list of strings.
    #

    def evaluate(self, board_state):

        heuristic_weights = {
            HEURISTIC_AGG_WEIGHT: -0.510066,
            HEURISTIC_NUMBER_OF_HOLES: -0.35663,
            HEURISTIC_BUMPINESS: -0.184483,
            HEURISTIC_CLEARED_LINES: 0.760666
        }

        heuristics = {
            HEURISTIC_AGG_WEIGHT: aggregate_height(board_state),  # minimize
            HEURISTIC_NUMBER_OF_HOLES: holes(board_state),  # minimize
            HEURISTIC_BUMPINESS: bumpiness(board_state),  # minimize
            HEURISTIC_CLEARED_LINES: lines_cleared(board_state)  # maximize
        }

        board_score = 0
        for heuristic in heuristics:
            board_score += heuristic_weights[heuristic] * heuristics[heuristic]
        return board_score

    def get_piece_alignments(self, piece):
        horizontal_flip_peice = quintris.hflip_piece(piece)
        return [
            ([], piece),
            (["h"], horizontal_flip_peice),
            (["n"], quintris.rotate_piece(piece, 90)),
            (["h", "n"], quintris.rotate_piece(horizontal_flip_peice, 90)),
            (["n", "n"], quintris.rotate_piece(piece, 180)),
            (["h", "n", "n"], quintris.rotate_piece(horizontal_flip_peice, 180)),
            (["n", "n", "n"], quintris.rotate_piece(piece, 270)),
            (["h", "n", "n", "n"], quintris.rotate_piece(horizontal_flip_peice, 270))
        ]

    def get_moves(self, quintris):
        moves = []
        board = quintris.get_board()
        current_piece_alignments, next_piece_alignments = self.get_piece_alignments(
            quintris.get_piece()[0]), self.get_piece_alignments(quintris.get_next_piece())

        score_list = []

        for move, piece in current_piece_alignments:
            for col in range(quintris.BOARD_WIDTH - len(piece[0]) + 1):
                row = 0
                while not quintris.check_collision(board, 0, piece, row + 1, col):
                    row += 1
                board_state = quintris.place_piece(board, 0, piece, row, col)[0]
                for next_move, next_piece in next_piece_alignments:
                    for next_col in range(quintris.BOARD_WIDTH - len(next_piece[0]) + 1):
                        next_row = 0
                        while not quintris.check_collision(board_state, 0, next_piece, next_row + 1, next_col):
                            next_row += 1
                        next_board_state = quintris.place_piece(board_state, 0, next_piece, next_row, next_col)[0]
                        score_list.append((move, col, self.evaluate(next_board_state)))
        move, col_placement, _ = max(score_list, key=lambda score: score[2])
        # checking if alignment of piece was changed
        if move:
            moves.extend(move)
        # adding left or right moves to align it in the desired column
        while True:
            if col_placement < quintris.col:
                moves.append("b")
                col_placement += 1
            elif col_placement > quintris.col:
                moves.append("m")
                col_placement -= 1
            else:
                break
        return moves

    # This is the version that's used by the animted version. This is really similar to get_moves,
    # except that it runs as a separate thread and you should access various methods and data in
    # the "quintris" object to control the movement. In particular:
    #   - quintris.col, quintris.row have the current column and row of the upper-left corner of the
    #     falling piece
    #   - quintris.get_piece() is the current piece, quintris.get_next_piece() is the next piece after that
    #   - quintris.left(), quintris.right(), quintris.down(), and quintris.rotate() can be called to actually
    #     issue game commands
    #   - quintris.get_board() returns the current state of the board, as a list of strings.
    #
    def control_game(self, quintris):
        # another super simple algorithm: just move piece to the least-full column
        while 1:
            time.sleep(0.1)

            board = quintris.get_board()
            column_heights = [min([r for r in range(len(board) - 1, 0, -1) if board[r][c] == "x"] + [100, ]) for c in
                              range(0, len(board[0]))]
            index = column_heights.index(max(column_heights))

            if (index < quintris.col):
                quintris.left()
            elif (index > quintris.col):
                quintris.right()
            else:
                quintris.down()


###################
#### main program

(player_opt, interface_opt) = sys.argv[1:3]

try:
    if player_opt == "human":
        player = HumanPlayer()
    elif player_opt == "computer":
        player = ComputerPlayer()
    else:
        print("unknown player!")

    if interface_opt == "simple":
        quintris = SimpleQuintris()
    elif interface_opt == "animated":
        quintris = AnimatedQuintris()
    else:
        print("unknown interface!")

    quintris.start_game(player)

except EndOfGame as s:
    print("\n\n\n", s)
