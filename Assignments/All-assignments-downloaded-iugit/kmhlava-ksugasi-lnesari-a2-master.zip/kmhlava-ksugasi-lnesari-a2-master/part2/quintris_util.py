def heights(board_state):
    heights_list = [0] * len(board_state[0])
    for col in range(len(board_state[0])):
        for row in range(len(board_state)):
            if board_state[row][col] == "x":
                heights_list[col] = len(board_state) - row
                break
    return heights_list


def aggregate_height(board_state):
    return sum(heights(board_state))


def bumpiness(board_state):
    height_list = heights(board_state)
    b = 0
    for i in range(1, len(height_list)):
        b += abs(height_list[i - 1] - height_list[i])
    return b


def holes(board_state):
    height_list = heights(board_state)
    holes = 0
    for col in range(len(board_state[0])):
        for row in range(len(board_state) - height_list[col], len(board_state)):
            holes += 1 if board_state[row][col] != "x" else 0
    return holes


def lines_cleared(board_state):
    cleared_lines_count = 0
    max_height = max(heights(board_state))
    for row in range(len(board_state) - max_height, len(board_state)):
        s = 0
        for col in range(len(board_state[0])):
            s += 1 if board_state[row][col] == "x" else 0
        if s == len(board_state[0]):
            cleared_lines_count += 1
    return cleared_lines_count
