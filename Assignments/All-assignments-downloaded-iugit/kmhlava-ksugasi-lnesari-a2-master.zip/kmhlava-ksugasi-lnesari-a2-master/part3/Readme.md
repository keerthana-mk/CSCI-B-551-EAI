# Part 3: Truth be Told
## **Problem Statement:**
Classify Hotel reviews using Naive Bayes Classifier.The two types of classes are "**Truthful**" and "**Deceptive**".

## **Approach:**

### 1. **Naive Bayes Classifier**
Naive Bayes Classifier predicts the class to which a review belongs through calculating the conditional probability P (class = j | review = d). It uses the Bayes rule to calculate this conditional probability. It is as following
<center>P (A | B) = P (B|A)P (A)/P (B)</center>
Applying the Bayes rule, we can find the conditional probability as:
<center>P(class=A|review=d) = P(review=d|class=A) P(class=A) / P(review=d)</center>

We find this conditional probability for each of the class A, and compare the probabilities. The class for which this
conditional probability will be the highest against the class B will be the one we predict.
<center>P (A| w<sub>1</sub>, w<sub>2</sub>,... w<sub>n</sub>) / P (B| w<sub>1</sub>, w<sub>2</sub>,... w<sub>n</sub> ) > 1</center> where review consists of  w<sub>1</sub>, w<sub>2</sub>,... w<sub>n</sub>.
                
Since we compare these conditional probabilities we can safely ignore the denominator i.e P(review  = d)

1.1 **Calculating P(reviews = d | class = A):**

P(review = d | class = A) is probability of words in review d being present in class A.
In order to calculate P (document = d | class = j), we do the following:

1. Split the reviews into words.
2. Calculate the probability of each word occurring in a review given the class as 
    <center>frequency of word / total number of words in class A</center>
3. Multiply these probabilities of words in review given the class, to get the probability of review given class. We can do this,
because **Naive bayes assumes conditional independence.**

1.2  **Calculating P(class = A):**

number of reviews in class A / total reviews

Once we calculate the above probabilities, we can calculate P (class = A|review = d) using Bayes rule for each
of the classes (truthful and deceptive). Then we can compare them to come up with a prediction.

### 2. Smoothing Parameters
If a particular word has not occurred at all in training set for a given class, during prediction, it will cause the product
of probabilities to be 0. Irrespective of how likely that word would have been predicted for that given class, due
to this word its conditional probability becomes 0.

This is a very likely scenario in real world. In order to circumvent this and improve predictions, we add smoothing
parameters. Smoothing parameters allows us to express prior knowlege about the data. In our case, it adds a non
zero positive value to the word frequencies that will ensure the cases of zero probabilities will be handled.
With a smoothing parameter *m*.

### 3. Data Processing
Following data preprocessing has been applied both the training and test sets before training the model.
1. **Punctuation removal:** From each of the document, all the punctuations such as [!, ?, #, @, &, .] etc have been
removed. This will make words ’Happy!!!’, ’Happy!?’, ’Happy.’ all the same as ’Happy’.
2. **Convert to lower case:** All the documents have been converted to lower case. This will make words like
’Happy’, ’HAPPY’, ’happy’ all same as ’happy’.

With preprocessing, we concentrate usages of same words in conjunction with punctuations, different cases. This
will contribute to increase frequency and subsequently the likelihood probabilities.
### 3. Implementation

1. <b><i>load_file():</i></b>
   The *load_file()* takes the Training and testing file and parses the files into labels, classes and objects (list of reviews).


2. <b><i>calculateFreq():</i></b>
   The *calculateFreq()* takes the training data as input and calculates the frequency of the words in each reviews.We create two dictionary maps 
   * truthful{} map
   * deceptive{} map
   
   The words in review against truthful label in train data are classified into truthful map and the review against a deceptive map is
   classified into deceptive map. We also calculate the total count of truthful and deceptive reviews. And also the sum of frequency of all words in the truthful and deceptive maps.We return the all these variables as a model to classifier().


3. <b><i>classifier():</i></b>
   The *classifier()* takes the training data and test data as input and returns the prediction of a review in the test data.
   The predict() takes each review in test data and calculates to decide if the review is truth or deceptive using the model.


4. <b><i>predict():</i></b>
   The *predicts()* takes the review in test data, model and smoothing parameter as input.For every word in the review
   Using the Naive Bayes formula, we calculate the probability of product of all the words in the truthful and deceptive map.
   We use a smoothing parameters to handle the words which have not appeared in training set but present in the test data.We multiply the class maps with this smoothing parameters.
   We are taking the log of the probabilities as the product result using Naive Bayes might be very lower values and cause an underflow and incorrect results. After calculating the sum probabilites of all 
   the word probabilities in the truthful and deceptive maps. We check if Sum of probability of truthful is greater than sum of probability of deceptive. If yes we return the result as 'truthful' else as 'deceptive'.
   ~~~
    if sum_P1 >= sum_P2:
        return 'truthful'
    else:
        return 'deceptive'
   ~~~
   
### 4. Results and Observations:
   **The final accuracy obtained from model using Naive Bayes is 86.5%**
#### Observations:
* As mentioned in the **data processing section 3**, we have preprocessed the data to get the accuracy of 86.5%. Without preprocessing the data we get a accuracy of 82.75%.By preprocessing the data we observe a increase in
accuracy by almost 3.75%.
* The concept of **smoothing parameters** in section 2, handles the cases where the words encountered in the 
   test data set was not found in the training set. On trying on different range of smoothing parameters between 0.1,...,1. The maximum accuracy was attained at 0.2.

   For small values of smoothing parameter m, the accuracy of model increase significantly. This increase in accuracy is attributed to elimination of zero probability cases, where some
   word is missing from the training data. Introduction of small smoothing parameter will ensure that the
   contributions of other words of review to the likelihood probability does not go in vain, while making sure that
   absence of this word is also accounted for.

