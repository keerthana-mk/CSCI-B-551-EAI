# SeekTruth.py : Classify text objects into two categories
#
# Name: Keerthana Sugasi and Username:ksugasi
#
# Based on skeleton code by D. Crandall, October 2021
#
import math
import string
import sys

# stop_words_list = ['i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're", "you've", "you'll",
#                    "you'd", 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', "she's",
#                    'her', 'hers', 'herself', 'it', "it's", 'its', 'itself', 'they', 'them', 'their', 'theirs',
#                    'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', "that'll", 'these', 'those', 'am',
#                    'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does',
#                    'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of',
#                    'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 'during', 'before',
#                    'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under',
#                    'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any',
#                    'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own',
#                    'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', "don't", 'should',
#                    "should've", 'now', 'd', 'll', 'm', 'o', 're', 've', 'y', 'ain', 'aren', "aren't", 'couldn',
#                    "couldn't", 'didn', "didn't", 'doesn', "doesn't", 'hadn', "hadn't", 'hasn', "hasn't", 'haven',
#                    "haven't", 'isn', "isn't", 'ma', 'mightn', "mightn't", 'mustn', "mustn't", 'needn', "needn't",
#                    'shan', "shan't", 'shouldn', "shouldn't", 'wasn', "wasn't", 'weren', "weren't", 'won', "won't",
#                    'wouldn', "wouldn't"]


def load_file(filename):
    objects = []
    labels = []
    with open(filename, "r") as f:
        for line in f:
            parsed = line.strip().split(' ', 1)
            labels.append(parsed[0] if len(parsed) > 0 else "")
            objects.append(parsed[1] if len(parsed) > 1 else "")

    return {"objects": objects, "labels": labels, "classes": list(set(labels))}


# classifier : Train and apply a bayes net classifier
#
# This function should take a train_data dictionary that has three entries:
#        train_data["objects"] is a list of strings corresponding to reviews
#        train_data["labels"] is a list of strings corresponding to ground truth labels for each review
#        train_data["classes"] is the list of possible class names (always two)
#
# and a test_data dictionary that has objects and classes entries in the same format as above. It
# should return a list of the same length as test_data["objects"], where the i-th element of the result
# list is the estimated classlabel for test_data["objects"][i]
#
# Do not change the return type or parameters of this function!
#
def calculateFreq(train_data):
    truth_map = {}
    deceptive_map = {}
    truthful_count = 0
    deceptive_count = 0
    for i in range(len(train_data['objects'])):
        preprocess_words = get_preprocessed_words(train_data['objects'][i], 1)
        if train_data['labels'][i] == "truthful":
            truthful_count += 1
            for word in preprocess_words:
                if word in truth_map:
                    truth_map[word] += 1
                else:
                    truth_map[word] = 1
        else:
            deceptive_count += 1
            for word in preprocess_words:
                if word in deceptive_map:
                    deceptive_map[word] += 1
                else:
                    deceptive_map[word] = 1
    sum_freq_truthful = sum(truth_map.values())
    sum_freq_deceptive = sum(deceptive_map.values())
    return truth_map, deceptive_map, truthful_count, deceptive_count, sum_freq_truthful, sum_freq_deceptive


def get_preprocessed_words(input,p_flag):
    if p_flag == 1:
        input = input.lower()
        # for stop_word in stop_words_list:
        #     input=input.replace(stop_word,'')
        # rm_punc = input
        rm_punc = input.translate(str.maketrans('', '', string.punctuation))
        words = rm_punc.strip().split(" ")
    else:
        words = input.strip().split(" ")
    result = []
    for word in words:
        result.append(word.strip())
    return result


def predict(review, model, m=0.2):
    truth_map, deceptive_map, truthful_count, deceptive_count, sum_freq_truthful, sum_freq_deceptive = model[0], model[
        1], model[2], model[3], model[4], model[5]
    sum_P1 = 0
    sum_P2 = 0
    test_word_list = get_preprocessed_words(review, 1)
    sum_freq_truthful += len(truth_map) * m
    sum_freq_deceptive += len(deceptive_map) * m
    for word in test_word_list:
        sum_P1 += math.log2((m + truth_map.get(word, 0)) / sum_freq_truthful)
        sum_P2 += math.log2((m + deceptive_map.get(word, 0)) / sum_freq_deceptive)

    sum_P1 += math.log2(truthful_count / (truthful_count + deceptive_count))
    sum_P2 += math.log2(deceptive_count / (deceptive_count + truthful_count))

    if sum_P1 >= sum_P2:
        return 'truthful'
    else:
        return 'deceptive'


def classifier(train_data, test_data):
    # This is just dummy code -- put yours here!
    prediction = []
    model = calculateFreq(train_data)
    for i in range(len(test_data['objects'])):
        prediction.append(predict(test_data['objects'][i], model))
    return prediction



if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise Exception("Usage: classify.py train_file.txt test_file.txt")

    (_, train_file, test_file) = sys.argv
    # Load in the training and test datasets. The file format is simple: one object
    # per line, the first word one the line is the label.
    train_data = load_file(train_file)
    test_data = load_file(test_file)
    if (sorted(train_data["classes"]) != sorted(test_data["classes"]) or len(test_data["classes"]) != 2):
        raise Exception("Number of classes should be 2, and must be the same in test and training data")

    # make a copy of the test data without the correct labels, so the classifier can't cheat!
    test_data_sanitized = {"objects": test_data["objects"], "classes": test_data["classes"]}

    results = classifier(train_data, test_data_sanitized)
    # calculate accuracy
    correct_ct = sum([(results[i] == test_data["labels"][i]) for i in range(0, len(test_data["labels"]))])
    print("Classification accuracy = %5.2f%%" % (100.0 * correct_ct / len(test_data["labels"])))
