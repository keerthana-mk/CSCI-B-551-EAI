# Assignment 1

## Part 1 - The 2021 Puzzle      -(By Keerthana Sugasi)

### **Search Abstraction:**

1. **Initial State:** A 5x5 board with misplaced tiles.
2. **Goal State:** A 5x5 board with tiles arranged in canonical form from 1 to 25.
3. **State space:**  A board obtained by sliding either row or column. It can be obtained by sliding the row left or right, column up or down and rotating outer and inner circle clockwise or anti-clockwise.
4. **Successor state or Transition Model:** A possible set of states obtained after making a move by sliding row or column or rotating outer and inner elements.
5. **Cost Function:** The cost of moving from initial cell position to current cell position. It gets incremented by one as we move down the tree to different level, which is identified by a sequence of moves.
6. **Heuristic Function:** The heuristic function gives the estimated cost from current state to goal state. Here the heuristic function is the Manhattan distance from the current cell position to the goal cell position. The total cost evaluation function f(s) = h(s)+g(s) where h(s)=heuristic cost and g(s)= move cost function.
   
### **How the program works:**

We are using A* search to arrange the 5x5 board with misplaced tiles to its canonical form with the minimal possible moves. We know that it is similar to 15-puzzle problem.

A* Search algorithm is an informed search algorithm as it uses information about path cost and also uses heuristics to find the optimal solution.

The heuristic function used here is Manhattan distance between the current state and the goal state. Manhattan distance is calculated by taking the absolute distance between the two axes coordinates.
 >Manhattan distance=|x1 - x2| + |y1 - y2|

 ### **Implementation:**

 The input is a file containing grid of numbers in their misplaced positions. The *main()* reads the files and stores it as tuple. But we need a 2D array to perform the operations, So we first convert into 2D List using the function *generate_2D_board()*. We also define the goal state to be a 2D array with the numbers stored in the canonical form using *get_goal_state()*.


 We need to perform the slide and rotation actions on the board to get to the goal state.

 1. ***Solve():***
   The solve() takes the input initial board. We define the initial cost to be 0 and moves taken so far to be empty string. We define the fringe to be a min heap and initialise with 4 parameters i.e
   * total function cost (move cost+heuristic cost)
   * move cost (initially 0)
   * moves (directions of rotation; initially empty string)
   * 2D board
  
  We heapify the fringe initially using heapq library. We run a loop until the fringe is empty or the goal state is reached. Inside, we pop using heapq.heappop() which will return the node with the lowest total function cost. We then check if it is the goal state, if yes we return the sequence of moves, otherwise we continue to find the successor states and populate the fringe with them.

  We also have implemented a 'Visited' logic which keeps track of the unique sequence of moves that has been traversed already hence making sure that no sequence of moves will be analyzed twice.

~~~
    fringe <- [(total cost function, cost, moves, board)]
    heapify(fringe)
    while fringe is not empty:
        cur_state <- fringe.pop()
        if cur_state is goal state:
            return cur_state.moves
        else:
            succ_states <- find_succ_sates(cur_state)
            for state in succ_states:
                if state is not visited:
                    add state to fringe
                    update visited for the state
            heapify(fringe)
~~~

2. ***successor():***
   The successor function takes the current state as input and generate the successors for a given node. WE know that rows can be moved only left or right and columns can be moved up and down. We can perform another four extra operations of rotation on inner and outer circles either clockwise and counter-clockwise.

   We create deep copy of the original board. The successor boards are created for every direction i.e each row and column are moved once for each permitted directions, the outer and inner circles are moved clockwise and counter-clockwise, and each resulting state is appended to the successor along with the heuristic, move cost, moves and board.

   We have created two functions *move_clockwise()* and *move_anti_clockwise()* which takes the starting position(row,col number), ending position(row,col number) as input which determines if the rotation is on outer elements or inner elements.

   In *move_clockwise()* rotate by pushing the first row to 
   >Right -> Down ->Left ->Up

    which completes a clockwise rotation. One elements gets pushed out in each move by sliding which is stored in previous and the is attached as head of next set of elements to be moved.

   In *move_anti_clockwise()* rotate by pushing the first column 
  
   > Down -> Right -> Up -> Left

    which completes a counter clockwise rotation. One elements gets pushed out in each move by sliding which is stored in previous and the is attached as head of next set of elements to be moved.

### **Heuristics**

After exploring a lot of heuristic and experimenting with all the heuristics, **Manhattan distance** was found to yield the most optimal result.

Other heuristics considered were:
1. Euclidean distance between two positions.
2. Number of misplaced tiles.
3. Sum of row and column displacement between current and goal state.
4. Difference in the position of cell entries between two states.

A heuristic h(n) is admissible if
for every node n,
> h(n) ≤ h * (n)

where h * (n) is the true cost to reach the goal state from n.
An admissible heuristic never overestimates the cost to reach the
goal, i.e., it is optimistic

### **Learning:**
* Code reusablility:
    1) Innovative way of converting columns to rows by transpose and re-using the move_left and move_right functions that translates to Up and Down operations on columns.
    2) Clockwise and counter-clockwise movement methods were implemented abstractly to accommodate higher order boards that contain more than one inner circle.
* Practical learning on why an heuristic is considered as in-admissible.
* The effect that an heuristic can have in reducing the total number of states that needs to be examined before reaching the goal state.
* Use of priority queues and Heaps in General and realization of Heaps using heapq library in python. 
* Inner working of how python handles lists and pointers. Advantage of copy() and copy.deepcopy(). I was initially using only copy function to create copies of board which resulted in the elements getting modified on the same board leading to wrong results. It was resolved after copy() was replaced with copy.deepcopy().


### **Questions from Assignment**

1. In this problem, what is the branching factor of the search tree?
   > The branching factor of the search tree is 24.
   > 10 moves pertaining to rows (right and left for 5 rows)
   > 10 moves pertaining to cols (up and down for 5 cols)
   > 2 moves pertaining to outer circle (clockwise and counter clockwise)
   > 2 moves pertaining to inner circle (clockwise and counter clockwise)

2. If the solution can be reached in 7 moves, about how many states would we need to explore before we found it if we used BFS instead of A* search? A rough answer is fine.

    > If we use BFS we will be exploring every node at every depth, so it will be 1 + 24 + 24<sup>2</sup> + 24<sup>3</sup> +...+ 24<sup>7</sup>. It is around 4.7 billion states.

### **References:**

1. https://towardsdatascience.com/a-star-a-search-algorithm-eb495fb156bb
2. https://www.geeksforgeeks.org/rotate-matrix-elements/
3. https://www.researchgate.net/publication/220654877_How_to_Solve_the_Torus_Puzzle

## Part 2 - Road trip     - (By Polukonda Kavya Tejaswi)

### Proceeding with the solution:
It has four parts to be solved:
1. Optimising distance
2. Optimising time
3. Optimising segments
4. Delivery finds the fastest route,  in expectation,  for  a  certain  delivery  driver. 

### Approach Explanation:

**Loading cities-gps dataset:**
For every line in the given dataset we are just splitting and appending it's values to the cities_gps list.

**Loading road_segments dataset:**
For every line in the given road-segments dataset we are just splitting and appending to the road_segments list.
road-segments.txt has one line per road segment connecting two cities.
The space delimited fields are:

- first city
- second city
- length (in miles)
- speed limit (in miles per hour)
- name of highway

To maximize/minimize the cost function(s), we implemented this problem using the Priority Queue. We created four different functions for each of the cost functions and 
called them according to the command line input.

Successor function:
Our successor function returned the set of all possible destinations from the current city. And then, each of these cities was added to the fringe and checked for 
their optimality in the corresponding cost function.

get_route function:
In get_route function based on the cost function we are going to return total-segments,total-miles,total-hours,total-delivery-hours.

### Heuristics:

1. Optimizing Segments
We minimize the number of segments by choosing the route segment which minimizes the total number of segments traversed.

2. Optimizing Distance
We optimize the distance by choosing the route segment which minimizes the total distance traversed.

3. Optimizing Time
We minimize the time by choosing the route segment which minimizes the total travel time, given the car, travels at full speed throughout the journey.

4. delivery finds  the  fastest  route,  in  expectation,  for  a  certain  delivery  driver.


### Checking condition:

If the cities[0] is equal to end_city i.e if we reach the destination then our task is to return the total-segments,route,total-miles,total-hours,total-delivery-hours.

Whenever  the driver drives on a road with a speed limit≥50 mph, there is a chance that a package will fall outof their truck and be destroyed.  They will have to drive to 
the end of that road, turn around,return to the start city to get a replacement, then drive all the way back to where they were (they won’t make the same mistake the 
second time they drive on that road).Consequently, this mistake will add an extra 2·(troad+ttrip) hours to their trip, where t trip is the time it took to get from the start
city to the beginning of the road, and troad is the time it takes to drive the length of the road segment.For a road of length miles, the probability p of this mistake happening
is equal to tanh(`1000)if the speed limit is≥50 mph, and 0 otherwise.1 This means that, in expectation, it will taketroad+p·2(troad+ttrip) hours to drive on this road. 

So, now we have to check if the speed is greater than or equal to 50. then, we are going to find the probability of mistake happening for distance cities[1].
then we are going to find the total time which is going to be the sum of length of the road segment and the distance from that location to the starting location.
Therefore, the extra delivery hours is going to be (cities[1]/cities[2]) + (2*p*total_time) if the speed limit is not greater than 50 we are just considering the normal time.


If the cities[0] is not equal to end_city we are just gonna push the distance,current location,path,segments,time,and delivery hours to the fringe again. It's going to happen till
we reach the destination.

Based on the cost function we are going to check this for all the functions: optimum_segments function,delivery function and optimum_time function

### Challenges faced and resolved:
By taking the roadsegment in the list increased the searching time for finding the particular cities highways and distance(miles). This issue was resolved by implementing it in dictionary
by taking values as length,speed limit. 


## Part 3 - Choosing teams - (By Nathaniel Priddy)
The problem of generating the optimal versions of team assignments is pathless. To build an efficient and correct search algorithm, we would need to define the following: state space, the successor function, edge weights, goal state, and the heuristic function. We formulated that the state space would be the placement of a student into a team, with the initial space being empty team assignments to begin with. The goal state is assigning n number of students (number of students who completed the survey) into teams that achieve the lowest amount of time that instructors would need to collectively spend on the team assignment. The successor function is every possible team assignment for a student. Since path is not associated with this problem (we're just interested in the end state), there is  not a cost function associated with how close we are to achieving the end state. We can, however, calculate the potential cost of placing a student into a team, utilizing edge weights. We take into consideration the following weights: creating a new team (adds 5 minutes of grading), placing the student in the desired group size (failure to do so adds 2 minutes of time for that student), assigning a student to their requested student (failure to do so adds a 5% probability times 60 minutes per failed student request), and fullfilling requested student exclusions (adds 10 minutes for each student assignment that was requested they requested to be excluded from). These costs are taken into account on the heuristic function. The heuristic function prioritizes successor states with the lowest cost associated, so the optimistic function is h(s) = 0, as in, this successor state does not increase cost, with the best case being it actually decreases cost. Since 0 is the lowest, most optimistic cost possible, this function is admissible.

Now that we have established the required elements to create an effective search algorithm, we then created a local search algorithm to complete this program. First, the program takes a data input of a text file with three fields: student requestor, requested team size and individuals, requested exclusions. The program will take this file, split each field into their respective fields, then split each subfield into their individual sub-elements, allowing easy computation on sublists. The program then randomly iterates on the parent lines (to prevent recomputation of the previous goal state), and starts computing optimal teams. It sends the first requestor to the team builder function, which computes the cost of adding each other requestor to the team utilizing the edge weights that were previously discussed. This cost is evaluated utilizing our previous cost with our heuristic function, which then allows the team builder to assign to the team, or move to the next state. Once an optimal team is computed, the program then moves onto the next student that has of yet to be assigned. Once the goal state is reached (every student is assigned to a team), the program yields the results. These results are the list of assigned teams and the total cost of the team assignments. Once these results are yielded, the entire process is repeated. At this point, we introduce one extra logical check. In order to prevent sub-optimal results from being computed, if an in-progress goal state cost exceeds the cost of a previous goal state, the program will abandon the current in-progress goal state and begin computing a new goal state. Program execution loops indefinitely, allowing either the user or another execution program to end our search program.

After designing the necessary attributes of the search algorithm, we implemented a few different methods to try to optimize the code. We had originally decided to pull the students for the teams at random, as to allow the program a chance to compute different solutions. One thought that we had was to capture the lowest scored teams over time, and then compute against these nodes to see if an even more optimal solution could be computed. Resources and experience were just lacking to implement this method. Creating a secondary thread to compute this could work, but we did not have the knowledge to ensure that this result would be the last output. Another thought was to calculate the "collateral cost", or cost of assigning a student to a team when another person on their team requested this specific student. This method actually decreased performance rather than excluding this extra cost. As it is though, we compute the cost of each team assignment as we introduce them into the algorithm.
