# Assignment 1

## Part 1 - The 2021 Puzzle

### **Search Abstraction:**

1. **Initial State:** A 5x5 board with misplaced tiles.
2. **Goal State:** A 5x5 board with tiles arranged in canonical form from 1 to 25.
3. **State space:**  A board obtained by sliding either row or column. It can be obtained by sliding the row left or right, column up or down and rotating outer and inner circle clockwise or anti-clockwise.
4. **Successor state or Transition Model:** A possible set of states obtained after making a move by sliding row or column or rotating outer and inner elements.
5. **Cost Function:** The cost of moving from initial cell position to current cell position. It gets incremented by one as move down the tree to different level of moves which is identified by a sequence of moves.
6. **Heuristic Function:** The heuristic function gives the cost from current state to goal state.Here the heuristic function is the Manhattan distance from the current cell position to the goal cell position. The total cost evaluation function f(s) = h(s)+g(s) where h(s)=heuristic cost and g(s)= move cost function.
   
### **How the program works:**

We are using A* search to arrange the 5x5 board with misplaced tiles to its canonical form with the minimal possible moves. We know that it is similar to 15-puzzle problem.

A* Search algorithm is an informed search algorithm which as it uses information about path cost and also uses heuristics to find the optimal solution.

The heuristic function used here is Manhattan distance between the current state and the goal state.Manhattan distance is calculated by taking the absolute distance between the two axes coordinates.
 >Manhattan distance=|x1 - x2| + |y1 - y2|

 ### **Implementation:**

 The input is a file containing grid of numbers in their misplaced positions. The *main()* reads the files and stores it as tuple. But we need a 2D array to perform the operations, So we first convert into 2D List using the function *generate_2D_board()*. We also define the goal state to be a 2D array with the numbers stored in the canonical form using *get_goal_state()*.


 We need to perform the slide and rotation actions on the board to get to the goal state.

 1. ***Solve():***
   The solve() takes the input initial board. We define the initial cost to be 0 and moves takes so far to be empty string.We define the fringe to be a priority queue and initialise with 4 parameters i.e
   * total function cost (move cost+heuristic cost)
   * move cost (initially 0)
   * moves (directions of rotation; initially null string)
   * 2D board
  
  We heapify the fringe initially using heapq library. We run a loop until the fringe is empty or the goal state is reached. Inside, we pop using heapq.heappop() which will return the node with the lowest total function cost. We then check if it is the goal state, if yes we return the sequence of moves, otherwise we continue to find the successor states and populate the fringe with them.

  We also have implemented a 'Visited' logic which keeps track of the unique sequence of moves that has been traversed already hence making sure that no sequence of moves will be analyzed twice.

~~~
    fringe <- [(total cost function, cost, moves, board)]
    heapify(fringe)
    while fringe is not empty:
        cur_state <- fringe.pop()
        if cur_state is goal state:
            return cur_state.moves
        else:
            succ_states <- find_succ_sates(cur_state)
            for state in succ_states:
                if state is not visited:
                    add state to fringe
                    update visited for the state
            heapify(fringe)
~~~

2. ***successor():***
   The successor function takes the current state as input and generate the successors for a given node. WE know that rows can be moved only left or right and columns can be moved up and down. We can perform another two extra operations of rotation on inner and outer circles either clockwise and counter-clockwise.

   We create deep copy of the original board.We create successor boards for every direction i.e iterate through the rows and create a state with that move and append it to the successor along with the move cost, heuristic, moves and board.We perform the same operation for left, right on rows & up and down on columns.We convert the colums to row by transposing it and call the left and right which when transposed back, is equivalent to right and left move.

   We have created two functions *move_clockwise()* and *move_anti_clockwise()* which takes the starting position(row,col number), ending position(row,col number) as input which determines if the rotation is on outer elements or inner elements.

   In *move_clockwise()* rotate by pushing the first row to 
   >Right -> Down ->Left ->Up

    which completes a clockwise rotation. One elements gets pushed out in each move by sliding which is stored in previous and the is attached as head of next set of elements to be moved.

   In *move_anti_clockwise()* rotate by pushing the first column 
  
   > Down -> Right -> Up -> Left

    which completes a counter clockwise rotation. One elements gets pushed out in each move by sliding which is stored in previous and the is attached as head of next set of elements to be moved.

### **Heuristics**

After exploring a lot of heuristic and generating output with all the  heuristics, I have fixed on the **Manhattan distance** to be heuristic to calculate the minimum cost from current state to goal state.

Other heuristics considered were:
1. Euclidean distance between two positions.
2. Number of misplaced tiles.
3. Sum of row and column displacement between current and goal state.
4. Difference in the position of cell entries

A heuristic h(n) is admissible if
for every node n,
> h(n) ≤ h * (n)

where h * (n) is the true cost to reach the goal state from n.
An admissible heuristic never overestimates the cost to reach the
goal, i.e., it is optimistic

### **Learning:**
* Innovative way of converting columns to rows by transpose and re-using the left and right functions which perform the same Up and Down operations.
* How can an heuristic be in-admissible by practical knowledge.
* The effect that an heuristic can have in reducing the total number of states that needs to be examined before reaching the goal state.
* Use of and priority queues and Heaps in General and realization of Heaps using heapq library in python. 
* Inner working of how python handles lists and pointers. Advantage of copy() and copy.deepcopy(). Was initially using only copy function to create copies of board which resulted in the elements getting modified on the same board and messing up the results. It was resolved after copy() was replaced with copy.deepcopy().


### **Questions from Assignment**

1. In this problem, what is the branching factor of the search tree?
   > The branching factor of the search tree is 24.

2. If the solution can be reached in 7 moves, about how many states would we need to explore before we found it if we used BFS instead of A* search? A rough answer is fine.

    > We need to explore 24<sup>11</sup> states which is approximately 1.5x10<sup>15</sup> states. ------------------

### **References:**

1. https://towardsdatascience.com/a-star-a-search-algorithm-eb495fb156bb
2. https://www.geeksforgeeks.org/rotate-matrix-elements/
3. https://www.researchgate.net/publication/220654877_How_to_Solve_the_Torus_Puzzle









