#!/usr/local/bin/python3
# route.py : Find routes through maps
#
# Code by: Polukonda Kavya Tejaswi IU ID: 2000927324
#
# Based on skeleton code by V. Mathur and D. Crandall, January 2021
#


import sys
import math
from math import radians
import heapq
import ast

cities_gps = [ ]
road_segments = [ ]

#loading city-gps dataset
with open( "city-gps.txt" , "r" ) as file :
    for line in file :
        l = line.split( )
        cities_gps.append( [ l[ 0 ] , float( l[ 1 ] ) , float( l[ 2 ] ) ] )
#loading road-segments dataset
with open( "road-segments.txt" , "r" ) as file :
    for line in file :
        l = line.split( )
        road_segments.append( [ l[ 0 ] , l[ 1 ] , int( l[ 2 ] ) , float( l[ 3 ] ) , l[ 4 ] ] )
        road_segments.append( [ l[ 1 ] , l[ 0 ] , int( l[ 2 ] ) , float( l[ 3 ] ) , l[ 4 ] ] )
    #file.close()



place=[]
road_segments_dict={}
with open("road-segments.txt",'r') as f:
       for f_line in f:
                  
             line=f_line.split()
             place.append(line[0])
             place.append(line[1])

             if place[0] not in road_segments_dict:
                 road_segments_dict[place[0]]={}

             if place[1] not in road_segments_dict:
                 road_segments_dict[place[1]]={}
             # appending the values of miles, distance , highway    
             road_segments_dict[place[0]][place[1]]=(float(line[2]),float(line[3]),line[4]) 
             road_segments_dict[place[1]][place[0]] = (line[2], line[3], line[4])
             place.clear()
             


        
def distance_bw_cities( start_city , end_city ) :

    start_city_gps = [ city for city in cities_gps if city[ 0 ] == start_city ]
    end_city_gps = [ city for city in cities_gps if city[ 0 ] == end_city ]

#    print( "GPS" , start_city_gps )

    start_lat = float( start_city_gps[ 0 ][ 1 ] )
    end_lat = float( end_city_gps[ 0 ][ 1 ] )

    start_long = float( start_city_gps[ 0 ][ 2 ] )
    end_long = float( end_city_gps[ 0 ][ 2 ] )
#    
#    print(start_lat, start_long)
#    print(end_lat, end_long)

    distance = get_distance( radians(start_lat) ,radians(start_long) , radians(end_lat) , radians(end_long) )
    
    return (distance)

def get_distance( start_lat , start_long , end_lat , end_long ) :

    d_lat = end_lat - start_lat
    d_lng = end_long - start_long

    distance = (
         math.sin(d_lat / 2) ** 2
       + math.cos(start_lat)
       * math.cos(end_lat)
       * math.sin(d_lng / 2) ** 2
    )

    return( 3958.134 * ( 2 * math.atan2( math.sqrt( distance ) , math.sqrt( 1 - distance ) ) ) )  
  
        

def is_goal( succ , end_city ) :
    if ( succ == end_city ):
        return True
    
    
def successors( state , visited_cities ) :
    return  [ city[1:] for city in road_segments if ( city[0] == state ) and ( city[ 1 ] not in visited_cities ) ]
    

     
def distance( start_city , end_city) :
   
    location=start_city
    distance=0.0   
    segments=0
    time=0
    visited_cities= [ ]
    delivery_hours=0
    fringe=[(distance, location, [location], segments, time,delivery_hours )]
    
    heapq.heapify(fringe)
    

    while len( fringe ) > 0 :
        (curr_dist, curr_loc, route, segments, time, final_delivery_hours)=heapq.heappop(fringe)
        for cities in successors(curr_loc , visited_cities) :    
            visited_cities.append( cities[ 0 ] )    
            if (cities[0])==end_city:        
                if (cities[2])>=50:
                    p = math.tanh((cities[1])/1000)
                    total_time = time+(cities[1]/cities[2])
                    delivery_hours =  (cities[1]/cities[2]) + (2*p*total_time)
                else:
                    delivery_hours =  (cities[1]/cities[2])       
                return ((segments+1,route +[cities[0]], curr_dist+cities[1], time+(cities[1]/cities[2]),final_delivery_hours+delivery_hours) )   
            else:
                if (cities[2])>=50:
                    p = math.tanh((cities[1])/1000)
                    total_time = time+(cities[1]/cities[2])
                    delivery_hours =  (cities[1]/cities[2]) + (2*p*total_time)
                else:
                    delivery_hours =  (cities[1]/cities[2])
                                 
                heapq.heappush( fringe, [curr_dist + cities[1],cities[0], route+[cities[0]] , segments+1 ,time+(cities[1]/cities[2]),final_delivery_hours+delivery_hours])                

    return False

        
        


def segments( start_city , end_city) :
   
    location=start_city
    distance=0    
    segments=0
    time=0
    visited_cities= [ ]
    delivery_hours=0
    
    fringe=[(segments, location, [location], distance, time, delivery_hours)]
    
    heapq.heapify(fringe)
    

    while len( fringe ) > 0 :
        (segments, curr_loc, route, curr_dist, time, final_delivery_hours)=heapq.heappop(fringe)
        
        
        
        for cities in successors(curr_loc , visited_cities) :
            
            visited_cities.append( cities[ 0 ] )
            
            if (cities[0]==end_city):
                
                if (cities[2])>=50:
                    p = math.tanh((cities[1])/1000)
                    total_time = time+(cities[1]/cities[2])
                    delivery_hours =  (cities[1]/cities[2]) + (2*p*total_time)

                else:
                    delivery_hours =  (cities[1]/cities[2])
                return ((segments+1,route +[cities[0]], curr_dist+cities[1], time+(cities[1]/cities[2]),final_delivery_hours+delivery_hours) )   
            else:
                if (cities[2])>=50:
                    p = math.tanh((cities[1])/1000)
                    total_time = time+(cities[1]/cities[2])
                    delivery_hours =  (cities[1]/cities[2]) + (2*p*total_time)
                else:
                    delivery_hours =  (cities[1]/cities[2])
                    
            
                           
                heapq.heappush( fringe, [segments+1 , cities[0], route+ [cities[0]] , curr_dist + cities[1], time+(cities[1]/cities[2]), final_delivery_hours+delivery_hours])


def delivery( start_city , end_city) :
   
    location=start_city
    distance=0    
    segments=0
    time=0
    visited_cities= [ ]
    delivery_hours=0
    fringe=[(delivery_hours, location, [location], segments,time,distance )]
    
    heapq.heapify(fringe)
    

    while len( fringe ) > 0 :
        (final_delivery_hours, curr_loc, route, segments, time,curr_dist)=heapq.heappop(fringe)
        for cities in successors(curr_loc , visited_cities) :    
            visited_cities.append( cities[ 0 ] )    
            if (cities[0])==end_city:        
                        
                if (cities[2])>=50:
                    p = math.tanh((cities[1])/1000)
                    total_time = time+(cities[1]/cities[2])
                    delivery_hours =  (cities[1]/cities[2]) + (2*p*total_time)
                else:
                    delivery_hours =  (cities[1]/cities[2])       
                return ((segments+1,route +[cities[0]], curr_dist+cities[1], time+(cities[1]/cities[2]),final_delivery_hours+delivery_hours) )   
            else:
                if (cities[2])>=50:
                    p = math.tanh((cities[1])/1000)
                    total_time = time+(cities[1]/cities[2])
                    delivery_hours =  (cities[1]/cities[2]) + (2*p*total_time)
                else:
                    delivery_hours =  (cities[1]/cities[2])
                                
                heapq.heappush( fringe, [final_delivery_hours+delivery_hours, cities[0], route+[cities[0]] ,segments+1 ,time+(cities[1]/cities[2]), curr_dist + cities[1]])                

    return False


def time( start_city , end_city) :
   
    location=start_city
    distance=0    
    segments=0
    time=0
    visited_cities= [ ]
    delivery_hours=0
    fringe=[(time, location, [location], distance, segments,delivery_hours )]
    
    heapq.heapify(fringe)
    

    while len( fringe ) > 0 :
        (time, curr_loc, route, curr_dist, segments, final_delivery_hours)=heapq.heappop(fringe)
        for cities in successors(curr_loc , visited_cities) :    
            visited_cities.append( cities[ 0 ] )    
            if (cities[0])==end_city:        
                        
                if (cities[2])>=50:
                    p = math.tanh((cities[1])/1000)
                    total_time = time+(cities[1]/cities[2])
                    delivery_hours =  (cities[1]/cities[2]) + (2*p*total_time)
                else:
                    delivery_hours =  (cities[1]/cities[2])       
                return ((segments+1,route +[cities[0]], curr_dist+cities[1], time+(cities[1]/cities[2]),final_delivery_hours+delivery_hours) )   
            else:
                if (cities[2])>=50:
                    p = math.tanh((cities[1])/1000)
                    total_time = time+(cities[1]/cities[2])
                    delivery_hours =  (cities[1]/cities[2]) + (2*p*total_time)
                else:
                    delivery_hours =  (cities[1]/cities[2])
                                 
                heapq.heappush( fringe, [time+(cities[1]/cities[2]), cities[0], route+[cities[0]] , curr_dist + cities[1], segments+1 ,final_delivery_hours+delivery_hours])                

    return False


    
    
# !/usr/bin/env python3
import sys
def get_route(start, end, cost):
    if( cost == 'distance' ) :
        a,b,c,d,e=distance( start, end)
    elif( cost == 'segments' ) :
        a,b,c,d,e=segments( start , end)
    elif( cost == 'time' ) :
        a,b,c,d,e=time( start, end)
    elif(cost == 'delivery'):
        a,b,c,d,e = delivery(start,end)

    
    res=""
    route_taken=[]
        
    for i in b:
        if(i == start):
            res = i

        else:     
                  x=road_segments_dict[res][i]
                  miles=x[0]
                  speed =x[1]
                  highway=x[2]
                  route_taken.append((f"{i}",f"{highway} for {float(miles)} miles"))
                  res=i
                
            
            

    
    
    return {"total-segments" : len(route_taken), 
            "total-miles" : float(c), 
            "total-hours" : d, 
            "total-delivery-hours" : e, 
            "route-taken" : route_taken}

    
    


    
    """
    Find shortest driving route between start city and end city
    based on a cost function.

    1. Your function should return a dictionary having the following keys:
        -"route-taken" : a list of pairs of the form (next-stop, segment-info), where
           next-stop is a string giving the next stop in the route, and segment-info is a free-form
           string containing information about the segment that will be displayed to the user.
           (segment-info is not inspected by the automatic testing program).
        -"total-segments": an integer indicating number of segments in the route-taken
        -"total-miles": a float indicating total number of miles in the route-taken
        -"total-hours": a float indicating total amount of time in the route-taken
        -"total-delivery-hours": a float indicating the expected (average) time 
                                   it will take a delivery driver who may need to return to get a new package
    2. Do not add any extra parameters to the get_route() function, or it will break our grading and testing code.
    3. Please do not use any global variables, as it may cause the testing code to fail.
    4. You can assume that all test cases will be solvable.
    5. The current code just returns a dummy solution.
    """

    


# Please don't modify anything below this line
#
if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise(Exception("Error: expected 3 arguments"))

    (_, start_city, end_city, cost_function) = sys.argv
    if cost_function not in ("segments", "distance", "time", "delivery"):
        raise(Exception("Error: invalid cost function"))
    
    result = get_route(start_city, end_city, cost_function)

    # Pretty print the route
    for step in result["route-taken"]:
        print("   Then go to %s via %s" % step)

    print("\n          Total segments: %4d" % result["total-segments"])
    print("             Total miles: %8.3f" % result["total-miles"])
    print("             Total hours: %8.3f" % result["total-hours"])
    print("Total hours for delivery: %8.3f" % result["total-delivery-hours"])


