#!/usr/local/bin/python3
# assign.py : Assign people to teams
#
# Code by: Nathaniel Priddy
#
# Based on skeleton code by D. Crandall and B551 Staff, September 2021
#

import sys
import time
import random

def parse_file(input_file):
    input_list = []

    with open(input_file) as f:
        for line in f:
            # remove newline
            line = line.rstrip()

            # split into intial tuples
            tmp = line.split(" ")

            # split each element into sub elements of requestor, requested team, requested exclusions
            tmp1 = tmp[0]
            tmp2 = tmp[1].split("-")
            tmp3 = tmp[2].split(",")

            input_list.append((tmp1,tmp2,tmp3))

    return input_list

def heuristic_fn():
    return True

def cost(input_list, team):
    # Initial cost of 5 for grading team assignment
    cost = 5
    collateral_cost = 0

    exclude_chars = ["xxx", "zzz"]

    for t in team:
        for i in input_list:
            # Get index of tuple
            ii = input_list.index(i)
            if input_list[ii][0] == t:
                # Edge Case: If a student requests a specific team size and does not receive, add 2 minutes.
                if len(team) != len(input_list[ii][1]):
                        cost += 2
                # Edge case: If a student is assigned a teammate on their exclusion list, add 10 minutes for each assignment
                for x in input_list[ii][2]:
                    if x in team:
                        cost += 10
                # Edge case: If someone on the team requested a student and they are not on the team, add the 5% probability that they will share code, where it takes 60 minutes for the instructor to meet with them.
                for e in input_list[ii][1]:
                    if e not in exclude_chars and e not in team:
                        cost += (.05 * 60)
            else:
           #     # If a student not on team requested to be with a student on the team, add the 5% probability that they will share code, where it takes 60 minutes for the instructor to meet with them. 
                if t in input_list[ii][1] and input_list[ii][0] not in team:
                    collateral_cost += (.05 * 60)

    return cost, collateral_cost


def team_builder(input_list, requestor_line, assigned_students):
    current_team = []
    prev_team = []
    
    current_team.append(requestor_line[0])
    prev_team = current_team
    prev_team_cost_saved = 0

    team_cost, collateral_cost = cost(input_list, current_team)

    r = list(input_list)
    random.shuffle(r)

    for i in r:
        ii = input_list.index(i)
        if input_list[ii][0] != requestor_line[0] and input_list[ii][0] not in assigned_students:
            # Removes last student if team is at 3
            if len(current_team) == 3:
                current_team.pop()

            current_team.append(input_list[ii][0])

            prev_team_cost = team_cost
            prev_collateral_cost = collateral_cost
            team_cost, collateral_cost = cost(input_list, current_team)

            # Simple heurisitic to remove team member if cost increases
            if team_cost > prev_team_cost:
                current_team.pop()
            else:
                prev_team = current_team
                prev_team_cost_saved = team_cost
                
    
    return prev_team, prev_team_cost_saved

def compute_total_cost(team_list):
    # This function computes cost for yielded team
    team_cost = 0

    if len(team_list) > 0:
        for t in team_list:
            team_cost += t[1]

    return team_cost

def solver(input_file):
    """
    1. This function should take the name of a .txt input file in the format indicated in the assignment.
    2. It should return a dictionary with the following keys:
        - "assigned-groups" : a list of groups assigned by the program, each consisting of usernames separated by hyphens
        - "total-cost" : total cost (time spent by instructors in minutes) in the group assignment
    3. Do not add any extra parameters to the solver() function, or it will break our grading and testing code.
    4. Please do not use any global variables, as it may cause the testing code to fail.
    5. To handle the fact that some problems may take longer than others, and you don't know ahead of time how
       much time it will take to find the best solution, you can compute a series of solutions and then
       call "yield" to return that preliminary solution. Your program can continue yielding multiple times;
       our test program will take the last answer you 'yielded' once time expired.
    """
    # Adding 10 minute timeout
    timeout = time.time() + 60 * 10

    input_list = parse_file(input_file)

    final_list = []
    prev_final = []

    # This solution will never befound, but that's ok; program will be killed eventually by the
    #  test script.
    while time.time() <= timeout:
        assigned_students = []
        prev_cost = compute_total_cost(prev_final)
        current_cost = 0

        r = list(input_list)
        random.shuffle(r)

        for i in r:
            # Filter out assigned students
            if i[0] not in assigned_students:
                team_assignment = team_builder(input_list, i, assigned_students)
                
                # Assign team
                final_list.append(team_assignment)
                
                # Add assigned students
                for t in team_assignment[0]:
                    assigned_students.append(t)

            current_cost = compute_total_cost(final_list)

            if current_cost >= prev_cost and len(prev_final) != 0:
                final_list = []
                break

        if len(final_list) != 0:
            assigned_teams = []
            for f in final_list:
                team = ""
                for p in f[0]:
                    team += p + "-"
                team = team.rstrip("-")
                assigned_teams.append(team)
            
            prev_final = final_list
            final_list = []
        
            yield({"assigned-groups": assigned_teams, "total-cost" : current_cost})

        pass
    
if __name__ == "__main__":
    if(len(sys.argv) != 2):
        raise(Exception("Error: expected an input filename"))

    for result in solver(sys.argv[1]):
        print("----- Latest solution:\n" + "\n".join(result["assigned-groups"]))
        print("\nAssignment cost: %d \n" % result["total-cost"])
