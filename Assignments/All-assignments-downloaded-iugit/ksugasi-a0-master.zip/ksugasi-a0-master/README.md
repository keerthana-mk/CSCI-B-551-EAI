# Assignment 0
## Part 1 : Navigation - Route pichu

**__Problem__** : Find the shortest distance between the agent(p) and the me(@)

**Search abstraction:**

1. **Initial State** : The initial state of search abstraction is the map given in the .txt file. It contains a matrix where pichu's initial location is marked (p) and  final destination is marked (@).

2. **Goal State** : The goal state is pichu's final location must be '@' in the map. The pichu has to navigate through the empty spaces(.) and avoid walls(X) to reach the destination(@).

3. **State space** : The state space in the search abstraction is the set of reachable states from the initial position. Here the empty spaces are the reachable states which are denoted by (.) in the matrix.

4. **Successor state or Transition Model** : The successor function denotes the directions in which the agent(p) can move from a given state. The directions that the agent can move in are Left (L), Right(R), Up(U), Down(D).

5. **Cost Function** : The cost function is kept uniform/constant from one move to its next immediate reachable state. So if the agent moves in any one of the four directions, the cost increases by one.

### **How the program works**

* Breadth First Search(BFS) is being used to find the shortest distance using queue implementation i.e First In First Out(FIFO).
  
* It is assumed that the map contains dots(.), walls(X), p and @ only.
  
* To progress I have to get the initial position of pichu (p). Once we have the initial position we have to create the fringe and add the state to it.
  
*  Take the first state from fringe and check if it is the goal state.
*  If it not in the goal state then we do the following until the goal state is reached or search space is exhausted:
   *  Make a valid move for agent(p) in each of the four directions.
   *  Update the state to reflect the move.
   *  Add each of the new state into the fringe.
* If goal state is reached, return the cost and path.
* If search space is exhausted then return -1.

### **Problems faced or missing constraint**

1. The initial program template was running into an *infinite loop* of searching and adding states to fringe. 
2. The *failure scenario* - if the goal state is not reached - was not handled.

### **Solution Implementation**

1. Modifications to the Program Template:
  
     1. Fringe was initially only storing the agent's location and   distance traveled. However, we also want to record the path of travel for the agent. In order to achieve that, fringe was modified to store both agent's location and path traveled so far.
      
     2. Solution for Infinite loop: The program was running into an infinite loop as it was not keeping track of which nodes were being visited. This resulted in program adding the same nodes over and over again to the fringe. In order to resolve this, I have created an auxillary matrix called visited, which is of the same dimensions as input matrix, but stores whether the agent(p) has visited(1) the node or not(0). And we only add a location to fringe if it is unvisited(0).

      ~~~~~
       if visited[row][col] != 1:
           fringe.append(((row,col), (cost+1, updated_dir_string))) 
      ~~~~~~

2. **Search Function**:
   
   The input for the __search()__ is the map (matrix). On taking the input, first the program finds the initial position of pichu(p) and adds the following values to fringe:
   * pichu location,
   * cost (initially 0)
   * the direction string (initially empty string '')

   After adding the inital state to fringe, we do the following iteratively:
    1.  Pop out the fringe to access the current agent position and state (cost and direction string)
    2.  The move function is passed with the house_map, current agent position parameters. It will return the list of valid moves possible from the agent's current location.
    3.  For each of the returned valid moves, we check if it the goal state.
        1.  if we have reached the goal state, we return the cost and direction string.
        2.  if we have not reached the goal state, we add the details to fringe if the location we are moving the agent to has not yet been visited.

3. **Find_direction Function:**
    
    The __find_direction()__ takes the row and column indices and returns the direction pichu travels i.e either in L, U, R,D.
    While moving up and down the column index remains the same and the row index is changed. 
     * If the change in row_index is -1 then we have moved up from from the last move's row.
     * If the change in row_index is +1 then we have moved down from the last move's row.

    Similarly for moving Left and Right the row index will reamin constant and the col index will be changed.
     * If the change in col_index is -1 then we have moved Left from last move's column.
     * If the change in col_index is +1 then we have moved Right from last move's column.
  
    So if pichu is in middle space then it will have directions to move, if it is in the corner it will have 2 directions to move.

<hr/>

## Part 2 : Hide and Seek - Arrange_pichus

**__Problem__** : Given k number of pichus(agents) instead of 1, we have to place them such that they do not see each other horizontally, vertically or diagonally

**Search abstraction:**

1. **Initial State** : The initial state of search abstraction is the map given in the .txt file. It contains a matrix where pichu (p) and  me(@) are placed. One p is already placed in the map.

2. **Goal State** : The goal state is to arrange the given number of pichus in the map such that:
     * Two pichus do not see each other either horizontally, vertically or diagonally
     * The walls(X) and person(@) act as block and two pichus can be places in the same row, column or diagonal given there is a wall between them.
  
    The program should return a new house map with all given number of pichus placed satisfying the above condition. The number of pichus is given as a argument in the command-line while execution. If there is no solution then it should return False.

3. **State space** : The state space in the search abstraction consists of the empty spaces(.) where the pichus can be placed but satisfying the constraint they should not be able to each other.The pichu cannot be placed in the wall(X) and (@) positions.

4. **Successor state or Transition Model**  : The successor function in the program gives the successor states where the next pichu can be placed in any of the empty places map such that it does not fall in line of sight of any other agents.

5. **Cost function** : The cost function is constant or uniform. However it seems redundant or irrelevant since the different placement of pichus will also require to traverse all the nodes. 

### **Problem faced**

The initial code is placing the pichus without checking the constraints given in the problem. So in the output we can see pichus placed next to each other.

### **Solution Implementation**

To overcome the above problem, we need to add the code which brings the constraint in place.

To enforce the constraint specified in the program, following approach has been implemented:

1. We mark all the locations in the map that is in sight (either in row, col or both diagonals) of an agent with a flag V.
2. If there is a wall (X) or position (@) in the line of sight of an agent, the updation of map with visited V is stopped beyond that location.
3. While searching a position to place a new agent, we ignore the positions marked with visited flag V. **This will reduce the search space as we keep placing new agents in the map and hence improves the performance**.
4. The program will terminate either when required number(k) of agents are placed on the map or if the search space is exhausted (i.e entire map is marked with V or X or @ and no empty places . is found). 

Following are the code modifications:

   1. **Add_pichu function:**
        
        In the __add_pichu()__ function, After placing the agent in the location given, I have added the code to update the position in the upward, downward, left, right, North-east,/west and South-east/west directions with Visited flag (V) that is in line of sight of the agent. It should stop the updation on either encountering a wall(X) or @ in the path of any of directions. 

   1. **Solve function:**
   2. 
        The __solve()__, takes the inputs: house map and number of agents k. 
      1.   I am adding a function to find the initial position of pichu and update all the eligible position in all directions to V marking it as visited. 
      2.   Fringe is then initalized with the initial state of map updated with visited flags.
      3.   We then do the following iteratively until fringe is empty:
           1.   pop the fringe and find the successor states by calling the successor function. It gives all posibile states for placement of next agent.
           2.   for each state returned by the successor function, we check if it is the final state.
                1.   if the final state is reached, then we return the state.
                2.   if final state is not reached, we add the state to fringe

      4. if no placement was found, then we return False. 

### **Citations**

1.https://medium.com/@egemenokte/solving-the-8-queens-puzzle-recursively-with-python-6440078b68ad

2.https://www.geeksforgeeks.org/breadth-first-search-or-bfs-for-a-graph/










