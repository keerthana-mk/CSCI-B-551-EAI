#!/usr/local/bin/python3
#
# arrange_pichus.py : arrange agents on a grid, avoiding conflicts
#
# Submitted by : [Name: Keerthana Sugasi AND Username:ksugasi]
#
# Based on skeleton code in CSCI B551, Fall 2021.

import sys
import timeit

# Parse the map from a given filename
def parse_map(filename):
	with open(filename, "r") as f:
		return [[char for char in line] for line in f.read().rstrip("\n").split("\n")][3:]

# Count total # of pichus on house_map
def count_pichus(house_map):
    return sum([ row.count('p') for row in house_map ] )

# Return a string with the house_map rendered in a human-pichuly format
def printable_house_map(house_map):
    return "\n".join(["".join(row) for row in house_map])

# Add a pichu to the house_map at the given position, and return a new house_map (doesn't change original)
def add_pichu(house_map, row, col):
    new_house_map = [r[:] for r in house_map]
    #updaing visited for pichu row upwards until obstacle is met
    for i in range(row, -1, -1):
        if new_house_map[i][col] == 'X' or new_house_map[i][col]=='@':
            break
        new_house_map[i][col]='V'
    #updaing visited for pichu row downwards until obstacle is met
    for i in range(row, len(new_house_map), 1):
        if new_house_map[i][col] == 'X' or new_house_map[i][col]=='@':
            break
        new_house_map[i][col]='V'

    #updaing visited for pichu col towards left until obstacle is met
    for i in range(col,-1,-1):
        if new_house_map[row][i] == 'X' or new_house_map[row][i]=='@':
            break
        new_house_map[row][i] = 'V'
    
    #updaing visited for pichu col towards right until obstacle is met
    for i in range(col,len(new_house_map[row]),1):
        if new_house_map[row][i] == 'X' or new_house_map[row][i]=='@':
            break
        new_house_map[row][i] = 'V'
    
    #updaing visited for pichu col towards diagonals (south-west)until obstacle is met
    diag_row=row
    diag_col=col
    while (diag_row>=0 and diag_col >= 0) and (new_house_map[diag_row][diag_col] != 'X' and new_house_map[diag_row][diag_col] != '@'):
        new_house_map[diag_row][diag_col] = 'V'
        diag_row -= 1
        diag_col -= 1

    #updaing visited for pichu col towards diagonals (north-west)until obstacle is met
    diag_row=row
    diag_col=col
    while (diag_row < len(new_house_map) and diag_col < len(new_house_map[row])) and (new_house_map[diag_row][diag_col] != 'X' and new_house_map[diag_row][diag_col] != '@'):
        new_house_map[diag_row][diag_col] = 'V'
        diag_row += 1
        diag_col += 1
        
    #updaing visited for pichu col towards diagonals (south-west)until obstacle is met
    diag_row=row
    diag_col=col
    while (diag_row < len(new_house_map) and diag_col >= 0) and (new_house_map[diag_row][diag_col] != 'X' and new_house_map[diag_row][diag_col] != '@'):
        new_house_map[diag_row][diag_col] = 'V'
        diag_row += 1
        diag_col -= 1

    #updaing visited for pichu col towards diagonals (north-east)until obstacle is met
    diag_row=row
    diag_col=col
    while (diag_row >= 0 and diag_col < len(new_house_map[row])) and new_house_map[diag_row][diag_col] != 'X':
        new_house_map[diag_row][diag_col] = 'V'
        diag_row -= 1
        diag_col += 1

    new_house_map[row][col]='p'
    return new_house_map

# Get list of successors of given house_map state
def successors(house_map):
    return [ add_pichu(house_map, r, c) for r in range(0, len(house_map)) for c in range(0,len(house_map[0])) if house_map[r][c] == '.' ]

# check if house_map is a goal state
def is_goal(house_map, k):
    return count_pichus(house_map) == k 
        
# We have to find the initial position of pichu placed 
# inorder to mark the corresponding row, colums and
#  diagonals to visited

def find_initial_pichu(house_map):
    for i in range(len(house_map)):
        for j in range(len(house_map[i])):
            if house_map[i][j] == 'p':
                return (i,j)
    return (-1,-1)

def replace_v(house_map):
    for i in range(len(house_map)):
        for j in range(len(house_map[i])):
            if house_map[i][j] == 'V':
                house_map[i][j] = '.'
    return house_map

# Arrange agents on the map
#
# This function MUST take two parameters as input -- the house map and the value k --
# and return a tuple of the form (new_house_map, success), where:
# - new_house_map is a new version of the map with k agents,
# - success is True if a solution was found, and False otherwise.
#
def solve(initial_house_map,k):
    # updating the visited nodes for first pichu that is already placed. Since adding pichu whill update the visited, 
    # we just simulate adding of first pichu to the house_map, which will updated the eligible cells.

    # if number of pichus k = 1, then we can directly return the house map. as it is already placed
    if k == 1:
        return house_map, True

    inital_pichu_pos = find_initial_pichu(initial_house_map)
    if inital_pichu_pos[0] == -1 or inital_pichu_pos[1] == -1:
        return ([], False)
    initial_house_map[inital_pichu_pos[0]][inital_pichu_pos[1]]='.'
    initial_house_map = add_pichu(initial_house_map, inital_pichu_pos[0], inital_pichu_pos[1])
    #print(printable_house_map(initial_house_map))
    fringe = [(initial_house_map)]
    solution_count=0
    solutions = []
    while len(fringe) > 0:
        fringe_pop = fringe.pop()
        successors_list = successors(fringe_pop)
        for new_house_map in successors_list:
            if is_goal(new_house_map,k):
                solution_count+=1
                return(replace_v(new_house_map),True)
            else:   
                fringe.append(new_house_map)
    return([], False)
# Main Function
if __name__ == "__main__":
    house_map=parse_map(sys.argv[1])
    # This is k, the number of agents
    k = int(sys.argv[2])
    print ("Starting from initial house map:\n" + printable_house_map(house_map) + "\n\nLooking for solution...\n")
    if(k==0):
        print("Number of pichu cannot be {}",k)
    solution = solve(house_map,k)
   # print(timeit.default_timer())
    print ("Here's what we found:")
    print (printable_house_map(solution[0]) if solution[1] else "False")


