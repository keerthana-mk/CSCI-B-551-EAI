#!/usr/local/bin/python3
#
# route_pichu.py : a maze solver
#
# Submitted by : [Name: Keerthana Sugasi AND Username: ksugasi@iu.edu]
#
# Based on skeleton code provided in CSCI B551, Fall 2021.

import sys

# Parse the map from a given filename
def parse_map(filename):
    with open(filename, "r") as f:
        return [[char for char in line] for line in f.read().rstrip("\n").split("\n")][
            3:
        ]


# Check if a row,col index pair is on the map
def valid_index(pos, n, m):
    return 0 <= pos[0] < n and 0 <= pos[1] < m


# Find the possible moves from position (row, col)
def moves(map, row, col):
    moves = ((row + 1, col), (row - 1, col), (row, col - 1), (row, col + 1))

    # Return only moves that are within the house_map and legal (i.e. go through open space ".")
    valid_moves = [
        move
        for move in moves
        if valid_index(move, len(map), len(map[0])) and (map[move[0]][move[1]] in ".@")
    ]
    # print("number of valid moves: {}".format(len(valid_moves)))
    return valid_moves


# Find_direction function takes the start and
# end position of the move and defines the direction
# of the move i.e either in Left(L), Right(R), Up(U),
# Down(D).

def find_direction(start_pos, end_pos):
    if end_pos[0] == start_pos[0] + 1:
        return "D"
    elif end_pos[0] == start_pos[0] - 1:
        return "U"
    elif end_pos[1] == start_pos[1] + 1:
        return "R"
    elif end_pos[1] == start_pos[1] - 1:
        return "L"


# Perform search on the map
#
# This function MUST take a single parameter as input -- the house map --
# and return a tuple of the form (move_count, move_string), where:
# - move_count is the number of moves required to navigate from start to finish, or -1
#    if no such route exists
# - move_string is a string indicating the path, consisting of U, L, R, and D characters
#    (for up, left, right, and down)
def search(house_map):
    # Find pichu start position
    rows = len(house_map)
    cols = len(house_map[0])
    # Add visited to prevent from function going into infinite loop and also to prevent revisiting of nodes. 
    visited = [[0] * cols for row_vis in range(rows)]
    # print(visited)
    pichu_location = [
        (row_i, col_i)
        for col_i in range(len(house_map[0]))
        for row_i in range(len(house_map))
        if house_map[row_i][col_i] == "p"
    ][0]
    start_state = (0, "")
    fringe = [(pichu_location, start_state)]
    final_state = (99999, "")
    while fringe:
        #  print("fringe has ", len(fringe), " elements")
        (curr_move, curr_state) = fringe.pop(0)
        visited[curr_move[0]][curr_move[1]] = 1
        for move in moves(house_map, *curr_move):
            #Add the direction of move
            updated_state = (
                curr_state[0] + 1,
                curr_state[1] + find_direction(curr_move, move),
            )
            if house_map[move[0]][move[1]] == "@":
                if updated_state[0] < final_state[0]:
                    final_state = updated_state
                # return (curr_state, 'DDDDDDD')  # return a dummy answer
            else:
                #if the node is already not visited the succ state gets added to fringe
                if visited[move[0]][move[1]] != 1:
                    fringe.append((move, updated_state))
    # Added the terminating condition and return the failure condition as -1.
    if final_state[0] == 99999:
        return (-1, "")
    else:
        return final_state


# Main Function
if __name__ == "__main__":
    house_map = parse_map(sys.argv[1])
    # print("house map",house_map)
    print("Shhhh... quiet while I navigate!")
    solution = search(house_map)
    print("Here's the solution I found:")
    print(str(solution[0]) + " " + solution[1])
