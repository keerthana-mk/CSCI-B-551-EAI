a=[1,2,3,4,5,6]
b=[1,2,3,4,5,6]
a.append(7)
b.append(7)

while len(a)>0:
    print(a.pop())
print ("===========================")
while len(b)>0:
    print(b.pop(0))

    20 RRRRRDLLLLLDRRRRRDDD

p.....
......
...p..
.....p
..p...
....p@

Here's what we found:
p.....
..p...
....p.
.p....
...p..
.....@